function openClose() {
    let navLinks = document.getElementById("responsive-nav-links");
    navLinks.classList.toggle("open-nav-links"); 
}

let toggleButton = document.getElementById("toggle-btn");

toggleButton.addEventListener("click", openClose);