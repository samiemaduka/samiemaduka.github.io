<html>
<head>
<link rel="shortcut icon"  href="images/logoicon_16.gif">
<title>Request Form</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-image: url(images/bg_01.jpg);
	background-repeat: repeat-x;
}
.style7 {font-family: Arial; font-size: 10px; color: #4a4a4a; font-weight: bold; }
.style9 {font-family: Arial; font-size: 10px; color: #0857B6; }
a:link {
	color: #0059B3;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #0059B3;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
	color: #0059B3;
}
.style17 {font-family: Arial, Helvetica, sans-serif; font-size: 10; }
.style18 {font-size: 10}
.style24 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style28 {color: #FF0000; font-size: 14px; }
.style31 {color: #FF0000; font-size: 10px; }
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }
//-->
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="MM_preloadImages('images/rollovers_03.jpg','images/rollovers_04.jpg','images/rollovers_05.jpg','images/rollovers_06.jpg','images/rollovers_02.jpg')">
<!-- ImageReady Slices (Interface.psd) -->
<table width="970" height="401" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
<tr>
		<td rowspan="2">
			<img src="images/index_01.jpg" width="227" height="118" alt=""></td>
		<td><a href="index.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image26','','images/rollovers_02.jpg',1)"><img src="images/index_02.jpg" name="Image26" width="79" height="72" border="0"></a></td>
<td><a href="About_The_Company.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image27','','images/rollovers_03.jpg',1)"><img src="images/index_03.jpg" name="Image27" width="93" height="72" border="0"></a></td>
<td><a href="Our_Services.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image28','','images/rollovers_04.jpg',1)"><img src="images/index_04.jpg" name="Image28" width="118" height="72" border="0"></a></td>
<td colspan="2"><a href="Track_Package_online.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image29','','images/rollovers_05.jpg',1)"><img src="images/index_05.jpg" name="Image29" width="124" height="72" border="0"></a></td>
<td><a href="Contact_Us.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image30','','images/rollovers_06.jpg',1)"><img src="images/index_06.jpg" name="Image30" width="111" height="72" border="0"></a></td>
<td colspan="2">
			<img src="images/index_07.jpg" width="218" height="72" alt=""></td>
  </tr>
	<tr>
		<td colspan="3">
			<img src="images/index_08.jpg" width="290" height="46" alt=""></td>
		<td colspan="5">
			<img src="images/index_09.jpg" width="453" height="46" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/index_10.jpg" width="227" height="172" alt=""></td>
		<td colspan="4">
			<img src="images/index_11.jpg" width="368" height="172" alt=""></td>
		<td colspan="3"><embed src="images/Image Rotation.swf" width="323" height="172"></embed></td>
  <td rowspan="2">
			<img src="images/index_13.jpg" width="52" height="276" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/index_14.jpg" width="227" height="104" alt=""></td>
		<td colspan="4">
			<img src="images/index_15.jpg" width="368" height="104" alt=""></td>
		<td colspan="3">
			<img src="images/index_16.jpg" width="323" height="104" alt=""></td>
	</tr>
	<tr>
		<td colspan="9"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td valign="bottom" class="style24"><strong>Request Form </strong></td>
              </tr>
              <tr>
                <td height="263" valign="top"><table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="126">&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><form action="" method="post" name="request" id="request">
                          <table width="100%" border="0" cellspacing="3" cellpadding="0">
                            <tr>
                              <td width="29%" class="style24">First Name<span class="style17"> <span class="style28">*</span></span></td>
                              <td width="71%"><label>
                                <input name="fname" type="text" id="fname" size="35">
                              </label></td>
                            </tr>
                            <tr>
                              <td valign="top" class="style24">Last Name<span class="style17"><span class="style28"> *</span></span></td>
                              <td><input name="lname" type="text" id="lname" size="35"></td>
                            </tr>
                            <tr>
                              <td valign="top"><span class="style24">Primary Phone </span><span class="style28">*</span></td>
                              <td><input name="priphone" type="text" id="priphone" size="35">
                                  <br>
                                  <span class="style31">(eg: XXXX-XXXXXXXXX )</span></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Secondary Phone</span></td>
                              <td><input name="secphone" type="text" id="secphone" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Email </span><span class="style28">*</span></td>
                              <td><input name="email" type="text" id="email" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Pick Up Date </span><span class="style28">*</span></td>
                              <td><input name="pickdate" type="text" id="pickdate" value="yyyy-mm-dd" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Pick Up Time </span><span class="style28">*</span></td>
                              <td><input name="picktime" type="text" id="picktime" size="35"></td>
                            </tr>
                            <tr>
                              <td valign="top"><span class="style24">Pick Up Address </span><span class="style28">*</span></td>
                              <td><label>
                                <textarea name="pickaddress" cols="35" rows="4" id="pickaddress"></textarea>
                              </label></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Pick Up City </span><span class="style28">*</span></td>
                              <td><input name="pickcity" type="text" id="pickcity" size="35"></td>
                            </tr>
                            <tr>
                              <td valign="top"><span class="style24">Pick Up State </span><span class="style28">*</span></td>
                              <td><input name="pickstate" type="text" id="pickstate" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Pick Up Zip Code</span><span class="style28"> *</span></td>
                              <td><input name="pickcode" type="text" id="pickcode" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Delivery Date </span><span class="style28">*</span> </td>
                              <td><input name="deliverydate" type="text" id="deliverydate" value="yyyy-mm-dd" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Delivery Time </span><span class="style28">*</span></td>
                              <td><input name="deliverytime" type="text" id="deliverytime" size="35"></td>
                            </tr>
                            <tr>
                              <td valign="top"><span class="style24">Delivery Address </span><span class="style28">*</span></td>
                              <td><textarea name="delivaddress" cols="35" rows="4" id="delivaddress"></textarea></td>
                            </tr>
                            <tr>
                              <td valign="top"><span class="style24">Delivery City</span><span class="style28"> *</span></td>
                              <td><input name="delicity" type="text" id="delicity" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Delivery State</span><span class="style28"> *</span></td>
                              <td><input name="delistate" type="text" id="delistate" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Delivery Zip Code </span><span class="style28">*</span></td>
                              <td><input name="delicode" type="text" id="delicode" size="15"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Vehicle Type </span><span class="style28">*</span></td>
                              <td><span class="ckCSSclear">
                                <select class="ckCSSinputnowidth " name="vehitype" id="vehicletype" size="1">
                                  <option selected="selected" value=""></option>
                                  <option value="Car">Car&nbsp;</option>
                                  <option value="Van">Van&nbsp;</option>
                                  <option value="Small Truck">Small Truck&nbsp;</option>
                                </select>
                              </span></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Type of Delivery </span><span class="style28">*</span></td>
                              <td><input name="delitype" type="text" id="delitype" size="15"></td>
                            </tr>
                            <tr>
                              <td><span class="style24">Delivery Contact Name </span><span class="style28">*</span></td>
                              <td><input name="contname" type="text" id="contname" size="35"></td>
                            </tr>
                            <tr>
                              <td height="25"><span class="style24">Contents of Package </span><span class="style28">*</span> </td>
                              <td><input name="conpackage" type="text" id="conpackage" size="35"></td>
                            </tr>
                            <tr>
                              <td><span class="style18"></span></td>
                              <td><label>
                                <input name="submit" type="submit" id="submit" onClick="MM_validateForm('fname','','R','lname','','R','priphone','','R','secphone','','R','email','','RisEmail','pickdate','','R','picktime','','R','pickcity','','R','pickstate','','R','pickcode','','R','deliverydate','','R','deliverytime','','R','delicity','','R','delistate','','R','delicode','','R','delitype','','R','contname','','R','conpackage','','R','pickaddress','','R','delivaddress','','R');return document.MM_returnValue" value="Submit Request">
                              </label></td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>&nbsp;</td>
                            </tr>
                          </table>
                      </form></td>
                    </tr>
                    <tr>
                      <td><?php
				   
				   if(isset($_REQUEST['submit'])){
   
                 $fname=$_REQUEST['fname'];
				 $lname=$_REQUEST['lname'];
				 $priphone=$_REQUEST['priphone'];
				 $secphone=$_REQUEST['secphone'];
				 $email=$_REQUEST['email'];
				 $pickdate=$_REQUEST['pickdate'];
				 $picktime=$_REQUEST['picktime'];
				 $pickaddress=$_REQUEST['pickaddress'];
				 $pickcity=$_REQUEST['pickcity'];
				 $pickstate=$_REQUEST['pickstate'];
				 $pickcode=$_REQUEST['cpickcode'];
				 $deliverydate=$_REQUEST['deliverydate'];
				 $deliverytime=$_REQUEST['deliverytime'];
				 $delivaddress=$_REQUEST['delivaddress'];
				 
				 $delicity=$_REQUEST['delicity'];
				 $delistate=$_REQUEST['delistate'];
				 $delicode=$_REQUEST['delicode'];
				 $vehitype=$_REQUEST['vehitype'];
				 $delitype=$_REQUEST['delitype'];
				 $contname=$_REQUEST['contname'];				 				 
				 $conpackage=$_REQUEST['conpackage'];
				 
				 				 
				 

				 $message=("Frist Name: $fname,
                            Last Name: $lname,
							Primary Phone: $priphone,
							Secondary Phone: $secphone,
							Email: $email,
							Pick Up Date: $pickdate,
							Pick Up Time: $deliverytime,
							Pick Up Address: $pickaddress,
							Pick Up City: $pickcity,
							Pick Up State: Pick Up State,
							Pick Up Zip Code: $pickcode,
							Delivery Date: $deliverydate,
							Delivery Time: $deliverytime,
							Delivery Address: $delivaddress,
							Delivery City: $delicity,
							Delivery State: $delistate,
							Delivery Zip Code: $delicode,
							Vehicle Type: $vehitype,
							Type of Delivery: $delitype,
							Delivery Contact Name: $contname,
							Contents of Package: $conpackage.");
				 
				 $to="info@femi-del.net";
				 $subject="Request Form";
				 $headers = "From: $email"; 
				 $sent = mail($to, $subject, $message, $headers) ; 
				 if($sent){
				 echo("<center>Your Request was sent successfully</center>");
				 }else{
				 
				 echo("<center>We encountered an error sending your mail</center>");
				 }
				 

				 
 
				}
		  ?></td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
  </tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="227" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="79" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="93" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="118" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="78" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="46" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="111" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="166" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="52" height="1" alt=""></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#E0DEDE">
  <tr>
    <td width="6%" height="77">&nbsp;</td>
    <td width="88%"><table width="100%" border="0">
      <tr>
        <td width="16%" height="14" class="style7"><a href="index.html">Home </a></td>
        <td width="28%"><span class="style7"><a href="Our_Services.html">Our Services </a></span></td>
        <td width="22%"><span class="style7"><a href="Air_Freight_Services.html">Air Freight Services </a></span></td>
        <td width="19%"><span class="style7"><a href="Sea_Freight_Services.html">Sea Freight Services </a></span></td>
        <td width="15%" rowspan="3" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td><span class="style7"><a href="About_The_Company.html">About Us </a></span></td>
        <td><span class="style7"><a href="Track_Package_online.php">Track Package Online </a></span></td>
        <td><span class="style7"><a href="Inland_Haluage_Services.html">Inland Haulage Services </a></span></td>
        <td><span class="style7"><a href="Cargo_Warehouse_Services.html">Cargo Warehousing Services </a></span></td>
      </tr>
      <tr>
        <td height="19" valign="top"><span class="style7"> <a href="Contact_Us.html">Contact Us </a></span></td>
        <td valign="top"><span class="style7"><a href="Consultancy_customs_Documentations.html">Consultancy &amp; Customs Documentations </a></span></td>
        <td valign="top" class="style9"><a href="request-form.php" class="style7">Request Form </a></td>
        <td valign="top">&nbsp;</td>
      </tr>
    </table></td>
    <td width="6%">&nbsp;</td>
  </tr>
  <tr>
    <td height="23">&nbsp;</td>
    <td align="center"><span class="style7">5 Star Express Courier Services &copy; All rights reserved</span></td>
    <td>&nbsp;</td>
  </tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>