<?php
	define('DB_HOST', 'localhost');
    define('DB_USER', 'vccghana_virus');
    define('DB_PASSWORD', 'efe@4199');
    define('DB_DATABASE', 'vccghana_virus');
?>