<?php
session_start();
	
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);

?>
<html>
<head>
<link rel="shortcut icon"  href="images/logoicon_16.gif">
<title>Track Package Online</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	background-image: url(images/bg_01.jpg);
	background-repeat: repeat-x;
}
.style7 {font-family: Arial; font-size: 10px; color: #4a4a4a; font-weight: bold; }
.style9 {font-family: Arial; font-size: 10px; color: #0857B6; }
a:link {
	color: #0059B3;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #0059B3;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
	color: #0059B3;
}
.style17 {font-family: Arial, Helvetica, sans-serif; font-size: 10; }
.style18 {font-size: 10}
.style24 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style28 {color: #FF0000; font-size: 14px; }
.style31 {color: #FF0000; font-size: 10px; }
.style12 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #006633; }

.fails {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 11px;
	color: #F00;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="MM_preloadImages('images/rollovers_03.jpg','images/rollovers_04.jpg','images/rollovers_05.jpg','images/rollovers_06.jpg','images/rollovers_02.jpg')">
<!-- ImageReady Slices (Interface.psd) -->
<table width="970" height="401" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
<tr>
		<td rowspan="2">
			<img src="images/index_01.jpg" width="227" height="118" alt=""></td>
		<td><a href="index.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image26','','images/rollovers_02.jpg',1)"><img src="images/index_02.jpg" name="Image26" width="79" height="72" border="0"></a></td>
<td><a href="About_The_Company.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image27','','images/rollovers_03.jpg',1)"><img src="images/index_03.jpg" name="Image27" width="93" height="72" border="0"></a></td>
<td><a href="Our_Services.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image28','','images/rollovers_04.jpg',1)"><img src="images/index_04.jpg" name="Image28" width="118" height="72" border="0"></a></td>
<td colspan="2"><a href="Track_Package_online.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image29','','images/rollovers_05.jpg',1)"><img src="images/index_05.jpg" name="Image29" width="124" height="72" border="0"></a></td>
<td><a href="Contact_Us.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image30','','images/rollovers_06.jpg',1)"><img src="images/index_06.jpg" name="Image30" width="111" height="72" border="0"></a></td>
<td colspan="2">
			<img src="images/index_07.jpg" width="218" height="72" alt=""></td>
  </tr>
	<tr>
		<td colspan="3">
			<img src="images/index_08.jpg" width="290" height="46" alt=""></td>
		<td colspan="5">
			<img src="images/index_09.jpg" width="453" height="46" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/index_10.jpg" width="227" height="172" alt=""></td>
		<td colspan="4">
			<img src="images/index_11.jpg" width="368" height="172" alt=""></td>
		<td colspan="3"><img src="images/f5_13.jpg" width="323" height="172"></td>
<td rowspan="2">
			<img src="images/index_13.jpg" width="52" height="276" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/index_14.jpg" width="227" height="104" alt=""></td>
		<td colspan="4">
			<img src="images/index_15.jpg" width="368" height="104" alt=""></td>
		<td colspan="3">
			<img src="images/index_16.jpg" width="323" height="104" alt=""></td>
	</tr>
	<tr>
		<td colspan="9"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td valign="bottom"><img src="images/trackpackageonline_03.gif" width="150" height="16"></td>
              </tr>
              <tr>
                <td height="263" valign="top"><table width="600" border="0" align="center">
                  <tr>
                    <td><fieldset>
                      <legend><span class="style12">Tracking Information</span></legend>
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td><form method="POST" name="tracking" id="tracking" action="tracking-exec.php">
                            <table width="100%" border="0" cellspacing="3" cellpadding="0">
                              <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td><?php
	if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
		echo '<table width="100%" class="fails">';
		foreach($_SESSION['ERRMSG_ARR'] as $msg) {
			echo '<tr><td>',$msg . '</td></tr>'; 
		}
		echo '</table>';
		unset($_SESSION['ERRMSG_ARR']);
	}
?></td>
                              </tr>
                              <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                              </tr>
                              <tr>
                                <td width="12%">&nbsp;</td>
                                <td width="24%"><span class="style24">Enter tracking number </span></td>
                                <td width="64%"><label>
                                  <input name="tracknumber" type="text" id="tracknumber" size="34">
                                </label></td>
                              </tr>
                              <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td><label>
                                  <input type="submit" name="button" id="button" value="Track">
                                </label></td>
                              </tr>
                            </table>
                          </form></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
  </tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="227" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="79" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="93" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="118" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="78" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="46" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="111" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="166" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="52" height="1" alt=""></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#E0DEDE">
  <tr>
    <td width="6%" height="77">&nbsp;</td>
    <td width="88%"><table width="100%" border="0">
      <tr>
        <td width="16%" height="14" class="style7"><a href="index.html">Home </a></td>
        <td width="28%"><span class="style7"><a href="Our_Services.html">Our Services </a></span></td>
        <td width="22%"><span class="style7"><a href="Air_Freight_Services.html">Air Freight Services </a></span></td>
        <td width="19%"><span class="style7"><a href="Sea_Freight_Services.html">Sea Freight Services </a></span></td>
        <td width="15%" rowspan="3" align="center">&nbsp;</td>
      </tr>
      <tr>
        <td><span class="style7"><a href="About_The_Company.html">About Us </a></span></td>
        <td><span class="style7"><a href="Track_Package_online.php">Track Package Online </a></span></td>
        <td><span class="style7"><a href="Inland_Haluage_Services.html">Inland Haulage Services </a></span></td>
        <td><span class="style7"><a href="Cargo_Warehouse_Services.html">Cargo Warehousing Services </a></span></td>
      </tr>
      <tr>
        <td height="19" valign="top"><span class="style7"> <a href="Contact_Us.html">Contact Us </a></span></td>
        <td valign="top"><span class="style7"><a href="Consultancy_customs_Documentations.html">Consultancy &amp; Customs Documentations </a></span></td>
        <td valign="top" class="style9"><a href="request-form.php" class="style7">Request Form </a></td>
        <td valign="top">&nbsp;</td>
      </tr>
    </table></td>
    <td width="6%">&nbsp;</td>
  </tr>
  <tr>
    <td height="23">&nbsp;</td>
    <td align="center"><span class="style7">5 StarExpress Courier Services &copy; All rights reserved</span></td>
    <td>&nbsp;</td>
  </tr>
</table>
<!-- End ImageReady Slices -->
</body>
</html>