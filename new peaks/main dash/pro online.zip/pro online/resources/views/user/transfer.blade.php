<?php
	if (Auth::user()->dashboard_style == "light") {
		$bgmenu="blue";
    $bg="light";
    $text = "dark";
} else {
    $bgmenu="dark";
    $bg="dark";
    $text = "light";

}
?> 
@extends('layouts.app')
@section('styles')
    @parent
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
@endsection

    @section('content')
        @include('user.topmenu')
        @include('user.sidebar')
        <div class="main-panel bg-{{$bg}}">
			<div class="content bg-{{$bg}}">
				<div class="page-inner">
                    <div class="mt-2 mb-4">
						<h1 class="title1 text-{{$text}}">User to User Transfer</h1>
					</div>
					<x-danger-alert/>
                    <x-success-alert/>
					<div class="row profile">
                        <div class="p-2 col-md-12">
                            <div class="card p-md-5 p-1 pb-md-0 pb-3 shadow-lg bg-{{$bg}}">
                                <div class="row">
                                    <div class="mb-3 col-md-12">
                                        <h4> <span class="text-primary">Account Balance:</span> <span class="text-{{$text}}">{{ $settings->currency . number_format(Auth::user()->account_bal)}}</span> </h4>
                                    </div>
                                    <div class="col-md-8 offset-md-2">
                                        <form method="post" action="javascript:void(0)" id="transferform">
                                            @csrf
                                            <div class="form-group">
                                                <h5 for="" class="text-{{$text}}">Receiver Email <span class=" text-danger">*</span></h5>
                                                <input type="email" name="email" class="form-control text-{{$text}} bg-{{$bg}}" required>
                                            </div>
                                            <div class="form-group">
                                                <h5 for="" class="text-{{$text}}">Amount to Send<span class=" text-danger">*</span></h5>
                                                <input type="number" name="amount" class="form-control text-{{$text}} bg-{{$bg}}" required>
                                            </div>
                                            <input type="hidden" name="password" id="acntpass">
                                            <div class="">
                                                <input type="submit" class="py-2 btn btn-primary btn-block" value="Send">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
				</div>	
			</div>
@endsection

@section('scripts')
    @parent
    <script>
        
       $('#transferform').on('submit', function() {
            (async () => {

                const { value: password } = await Swal.fire({
                    title: 'Input your password',
                    input: 'password',
                    inputLabel: 'Enter your account password to complete transfer',
                    inputPlaceholder: 'Enter your account password'
                })

                if (password) {

                    document.getElementById('acntpass').value = password;
                    $.ajax({
                        url: "{{route('transfertouser')}}",
                        type: 'POST',
                        data: $('#transferform').serialize(),
                        success: function(response) {
                            if (response.status === 200) {
                                Swal.fire({
                                    title: 'Success!',
                                    text: response.message,
                                    icon: 'success',
                                    confirmButtonText: 'Cool'
                                });
                                
                                setTimeout(() => {
                                    let url = "{{url('/dashboard/transfer-funds')}}";
			                        window.location.href = url;
                                }, 3000);
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: response.message,
                                    icon: 'error',
                                });
                            }
                        },
                        error: function(error) {
                            console.log(error);
                        },

                    });
                }else{
                    Swal.fire({
                        title: 'Error!',
                        text: 'Password is required',
                        icon: 'error',
                        confirmButtonText: 'Alright'
                    })
                }

            })()

        });
    </script>
    
@endsection