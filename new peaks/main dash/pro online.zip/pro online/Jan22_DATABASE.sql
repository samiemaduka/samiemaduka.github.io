-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 19, 2022 at 03:30 AM
-- Server version: 10.3.32-MariaDB-log-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bryngrgz_oct2021`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(25) NOT NULL,
  `user` int(35) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `device` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `user`, `ip_address`, `created_at`, `updated_at`, `device`, `browser`, `os`) VALUES
(27, 49, '127.0.0.1', '2021-10-25 12:49:31', '2021-10-25 12:49:31', 'WebKit', 'Chrome', 'Windows'),
(32, 17, '127.0.0.1', '2021-10-27 13:06:14', '2021-10-27 13:06:14', 'WebKit', 'Chrome', 'Windows'),
(33, 17, '127.0.0.1', '2021-10-27 13:06:14', '2021-10-27 13:06:14', 'WebKit', 'Chrome', 'Windows'),
(34, 17, '127.0.0.1', '2021-10-27 13:35:51', '2021-10-27 13:35:51', 'WebKit', 'Chrome', 'Windows'),
(35, 17, '127.0.0.1', '2021-10-27 13:35:51', '2021-10-27 13:35:51', 'WebKit', 'Chrome', 'Windows'),
(36, 17, '127.0.0.1', '2021-10-27 13:37:10', '2021-10-27 13:37:10', 'WebKit', 'Chrome', 'Windows'),
(37, 52, '127.0.0.1', '2021-10-27 13:49:43', '2021-10-27 13:49:43', 'WebKit', 'Chrome', 'Windows'),
(38, 52, '127.0.0.1', '2021-10-27 13:49:43', '2021-10-27 13:49:43', 'WebKit', 'Chrome', 'Windows'),
(39, 17, '127.0.0.1', '2021-11-01 08:12:25', '2021-11-01 08:12:25', 'WebKit', 'Chrome', 'Windows'),
(40, 17, '127.0.0.1', '2021-11-01 08:12:25', '2021-11-01 08:12:25', 'WebKit', 'Chrome', 'Windows'),
(41, 54, '127.0.0.1', '2021-11-01 10:31:35', '2021-11-01 10:31:35', 'WebKit', 'Chrome', 'Windows'),
(42, 54, '127.0.0.1', '2021-11-01 10:31:35', '2021-11-01 10:31:35', 'WebKit', 'Chrome', 'Windows'),
(43, 17, '127.0.0.1', '2021-11-15 09:11:48', '2021-11-15 09:11:48', 'WebKit', 'Chrome', 'Windows'),
(44, 17, '127.0.0.1', '2021-11-15 09:11:49', '2021-11-15 09:11:49', 'WebKit', 'Chrome', 'Windows'),
(45, 17, '127.0.0.1', '2021-11-16 09:03:02', '2021-11-16 09:03:02', 'WebKit', 'Chrome', 'Windows'),
(46, 17, '127.0.0.1', '2021-11-16 09:03:03', '2021-11-16 09:03:03', 'WebKit', 'Chrome', 'Windows'),
(47, 17, '127.0.0.1', '2021-11-16 12:55:54', '2021-11-16 12:55:54', 'WebKit', 'Chrome', 'Windows'),
(48, 17, '127.0.0.1', '2021-11-16 12:55:55', '2021-11-16 12:55:55', 'WebKit', 'Chrome', 'Windows'),
(49, 17, '127.0.0.1', '2021-11-17 08:36:49', '2021-11-17 08:36:49', 'WebKit', 'Chrome', 'Windows'),
(50, 17, '127.0.0.1', '2021-11-17 08:36:50', '2021-11-17 08:36:50', 'WebKit', 'Chrome', 'Windows'),
(51, 17, '127.0.0.1', '2021-11-17 11:07:18', '2021-11-17 11:07:18', 'WebKit', 'Chrome', 'Windows'),
(52, 17, '127.0.0.1', '2021-11-17 11:07:18', '2021-11-17 11:07:18', 'WebKit', 'Chrome', 'Windows'),
(53, 17, '127.0.0.1', '2021-11-22 08:28:17', '2021-11-22 08:28:17', 'WebKit', 'Chrome', 'Windows'),
(54, 17, '127.0.0.1', '2021-11-22 08:28:17', '2021-11-22 08:28:17', 'WebKit', 'Chrome', 'Windows'),
(55, 17, '127.0.0.1', '2021-11-29 08:26:00', '2021-11-29 08:26:00', 'WebKit', 'Chrome', 'Windows'),
(56, 17, '127.0.0.1', '2021-11-29 08:26:03', '2021-11-29 08:26:03', 'WebKit', 'Chrome', 'Windows'),
(57, 17, '127.0.0.1', '2021-12-02 09:46:19', '2021-12-02 09:46:19', 'WebKit', 'Chrome', 'Windows'),
(58, 17, '127.0.0.1', '2021-12-02 09:46:20', '2021-12-02 09:46:20', 'WebKit', 'Chrome', 'Windows'),
(59, 17, '127.0.0.1', '2021-12-06 10:56:23', '2021-12-06 10:56:23', 'WebKit', 'Chrome', 'Windows'),
(60, 17, '127.0.0.1', '2021-12-06 10:56:23', '2021-12-06 10:56:23', 'WebKit', 'Chrome', 'Windows'),
(61, 17, '127.0.0.1', '2021-12-06 14:51:26', '2021-12-06 14:51:26', 'WebKit', 'Chrome', 'Windows'),
(62, 17, '127.0.0.1', '2021-12-06 14:51:26', '2021-12-06 14:51:26', 'WebKit', 'Chrome', 'Windows'),
(63, 17, '127.0.0.1', '2021-12-07 09:07:26', '2021-12-07 09:07:26', 'WebKit', 'Chrome', 'Windows'),
(64, 17, '127.0.0.1', '2021-12-07 09:07:27', '2021-12-07 09:07:27', 'WebKit', 'Chrome', 'Windows'),
(65, 17, '127.0.0.1', '2021-12-08 09:52:14', '2021-12-08 09:52:14', 'WebKit', 'Chrome', 'Windows'),
(66, 17, '127.0.0.1', '2021-12-08 09:52:15', '2021-12-08 09:52:15', 'WebKit', 'Chrome', 'Windows'),
(67, 17, '127.0.0.1', '2021-12-13 08:46:06', '2021-12-13 08:46:06', 'WebKit', 'Chrome', 'Windows'),
(68, 17, '127.0.0.1', '2021-12-13 08:46:06', '2021-12-13 08:46:06', 'WebKit', 'Chrome', 'Windows'),
(69, 17, '127.0.0.1', '2021-12-16 08:33:45', '2021-12-16 08:33:45', 'WebKit', 'Chrome', 'Windows'),
(70, 17, '127.0.0.1', '2021-12-16 08:33:45', '2021-12-16 08:33:45', 'WebKit', 'Chrome', 'Windows'),
(71, 17, '127.0.0.1', '2022-01-07 09:01:23', '2022-01-07 09:01:23', 'WebKit', 'Chrome', 'Windows'),
(72, 17, '127.0.0.1', '2022-01-07 09:01:23', '2022-01-07 09:01:23', 'WebKit', 'Chrome', 'Windows'),
(73, 17, '127.0.0.1', '2022-01-07 13:58:32', '2022-01-07 13:58:32', 'WebKit', 'Chrome', 'Windows'),
(74, 17, '127.0.0.1', '2022-01-07 13:58:33', '2022-01-07 13:58:33', 'WebKit', 'Chrome', 'Windows'),
(75, 17, '127.0.0.1', '2022-01-14 12:50:47', '2022-01-14 12:50:47', 'WebKit', 'Chrome', 'Windows'),
(76, 17, '127.0.0.1', '2022-01-14 12:50:48', '2022-01-14 12:50:48', 'WebKit', 'Chrome', 'Windows'),
(77, 17, '105.112.33.62', '2022-01-14 13:39:28', '2022-01-14 13:39:28', 'WebKit', 'Chrome', 'Windows'),
(78, 17, '105.112.33.62', '2022-01-14 13:39:28', '2022-01-14 13:39:28', 'WebKit', 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_2fa_expiry` datetime DEFAULT current_timestamp(),
  `enable_2fa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disbaled',
  `token_2fa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pass_2fa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_style` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dark',
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acnt_type_active` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `firstName`, `lastName`, `email`, `email_verified_at`, `password`, `token_2fa_expiry`, `enable_2fa`, `token_2fa`, `pass_2fa`, `phone`, `dashboard_style`, `remember_token`, `acnt_type_active`, `status`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'Test', 'super@happ.com', NULL, '$2y$10$os3fPHLrHAGG2GkfLE0XhOjH3fI5Fmrc8rb.W3nxIC.Oxu9pX3clq', '2021-12-07 11:40:56', 'disabled', '16632', 'true', '34444443', 'light', NULL, 'active', 'active', 'Super Admin', '2021-03-10 12:55:53', '2021-12-07 08:41:19'),
(3, 'New', 'Admin', 'admin@happ.com', NULL, '$2y$10$zTovkvwyntf6ShVaFXtQm.nunRB.D0f1BzLmNv/kp1phijECbCR2m', '2021-05-05 12:39:11', 'disbaled', NULL, NULL, '2344', 'light', NULL, 'active', 'active', 'Admin', '2021-04-06 08:23:58', '2021-12-07 08:30:57');

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_refered` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `total_activated` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `earnings` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`id`, `agent`, `total_refered`, `total_activated`, `earnings`, `created_at`, `updated_at`) VALUES
(4, '17', '8', '0', '0', '2021-04-14 09:45:06', '2021-11-22 08:00:52');

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `symbol` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int(255) NOT NULL,
  `ref_key` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `ref_key`, `title`, `description`, `created_at`, `updated_at`) VALUES
(5, 'SMsJr1', 'What our Customer says!', 'Don\'t take our word for it, here\'s what some of our clients have to say about us', '2020-08-22 11:13:00', '2021-10-27 09:59:35'),
(11, 'anvs8c', 'About Us', 'About us header', '2020-08-22 11:32:29', '2021-10-27 10:21:22'),
(12, 'epJ4LI', 'Who we are', 'online trade \r\n                            is a solution for creating an investment management platform. It is suited for\r\n                            hedge or mutual fund managers and also Forex, stocks, bonds and cryptocurrency traders who\r\n                            are looking at runing pool trading system. Onlinetrader simplifies the investment,\r\n                            monitoring and management process. With a secure and compelling mobile-first design,\r\n                            together with a default front-end design, it takes few minutes to setup your own investment\r\n                            management or pool trading platform.', '2020-08-22 11:33:32', '2021-10-27 10:24:01'),
(13, '5hbB6X', 'Get Started', 'How to get started ?', '2020-08-22 11:33:55', '2021-10-27 10:25:09'),
(14, 'Zrhm3I', 'Create an Account', 'Create an account with us using your preffered email/username', '2020-08-22 11:34:11', '2021-10-27 10:25:29'),
(15, 'yTKhlt', 'Make a Deposit', 'Make A deposit with any of your preffered currency', '2020-08-22 11:34:26', '2021-10-27 10:25:52'),
(16, 'u0Ervr', 'Start Trading/Investing', 'Start trading with Indices commodities e.tc', '2020-08-22 11:34:56', '2021-10-27 10:26:12'),
(23, 'vr6Xw0', 'Our Investment Packages', 'Choose how you want to invest with us', '2020-08-22 11:37:43', '2021-10-27 09:58:51'),
(30, '52GPRA', 'Address', 'No 10 Mission Road, Nigeria', '2020-08-22 11:40:19', '2020-08-22 11:40:19'),
(31, '0EXbji', 'Phone Number', '+234 9xxxxxxxx', '2020-08-22 11:40:36', '2020-09-14 10:13:57'),
(32, 'HLgyaQ', 'Email', 'support@brynamics.xyz', '2020-08-22 11:41:14', '2020-08-22 12:23:55'),
(35, 'Mnag31', 'The Better Way to Trade & Invest', 'Online Trade helps over 2 million customers achieve their financial goals by helping them trade and invest with ease', '2021-10-27 09:42:23', '2021-10-27 09:42:23'),
(36, 'rXJ7JQ', 'Trade Invest stock, and Bond', 'Home page text', '2021-10-27 09:45:17', '2021-10-27 09:45:17'),
(37, 'J23T0Y', 'Security Comes First', 'Security Comes first', '2021-10-27 09:53:15', '2021-10-27 09:54:52'),
(38, '9HOR1z', 'Security', 'Online Trade uses the highest levels of Internet Security, and it is secured by 256 bits SSL security encryption to ensure that your information is completely protected from fraud.', '2021-10-27 09:56:13', '2021-10-27 09:56:13'),
(39, '7DH2G9', 'Two Factor Auth', 'Two-factor authentication (2FA) by default on all Online Trade accounts, to securely protect you from unauthorised access and impersonation.', '2021-10-27 09:56:26', '2021-10-27 09:56:26'),
(40, '5Vg32I', 'Explore Our Services', 'It’s our mission to provide you with a delightful and a successful trading experience!', '2021-10-27 09:56:38', '2021-10-27 09:56:38'),
(41, 'Vg6Gy7', 'Powerful Trading Platforms', 'Online Trade offers multiple platform options to cover the needs of each type of trader and investors .', '2021-10-27 09:56:53', '2021-10-27 09:56:53'),
(42, '1Sx1dl', 'High leverage', 'Chance to magnify your investment and really win big with super-low spreads to further up your profits', '2021-10-27 09:57:06', '2021-10-27 09:57:06'),
(43, 'YYqKx3', 'Fast execution', 'Super-fast trading software, so you never suffer slippage.', '2021-10-27 09:57:20', '2021-10-27 09:57:20'),
(44, 'yGg8xI', 'Ultimate Security', 'With advanced security systems, we keep your account always protected.', '2021-10-27 09:57:35', '2021-10-27 09:57:35'),
(45, 'xEWMho', '24/7 live chat Support', 'Connect with our 24/7 support and Market Analyst on-demand.', '2021-10-27 09:57:48', '2021-10-27 09:57:48'),
(46, '9SOtK1', 'Always on the go? Mobile trading is easier than ever with Online Trade!', 'Get your hands on our customized Trading Platform with the comfort of freely trading on the move, to experience truly liberating trading sessions.', '2021-10-27 09:58:05', '2021-10-27 09:58:05'),
(47, 'wOS1ve', 'Cryptocurrency', 'Trade and invest Top Cryptocurrency', '2021-10-27 09:59:07', '2021-10-27 09:59:07'),
(48, 'wuZlis', 'Hello!, How can we help you?', 'Hello!, How can we help you?', '2021-10-27 10:32:12', '2021-10-27 10:32:12'),
(49, '1TYkw0', 'Find the help you need', 'Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.', '2021-10-27 10:32:33', '2021-10-27 10:32:33'),
(50, 'rK6Yhn', 'FAQs', 'Due to its widespread use as filler text for layouts, non-readability is of great importance.', '2021-10-27 10:32:49', '2021-10-27 10:32:49'),
(51, 'HBHBLo', 'Guides / Support', 'Due to its widespread use as filler text for layouts, non-readability is of great importance.', '2021-10-27 10:33:03', '2021-10-27 10:33:03'),
(52, 'rCTDQh', 'Support Request', 'Due to its widespread use as filler text for layouts, non-readability is of great importance.', '2021-10-27 10:33:14', '2021-10-27 10:33:14'),
(53, 'kMsswR', 'Get Started', 'Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.', '2021-10-27 10:33:28', '2021-10-27 10:33:28'),
(54, 'EOUU7R', 'Get in Touch !', 'This is required when, for text is not yet available.', '2021-10-27 10:33:56', '2021-10-27 10:33:56'),
(56, 'ROu4q6', 'Contact Us', 'Contact Us', '2021-10-27 10:47:41', '2021-10-27 10:47:41');

-- --------------------------------------------------------

--
-- Table structure for table `cp_transactions`
--

CREATE TABLE `cp_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `txn_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Item_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_plan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_tele_id` int(11) DEFAULT NULL,
  `amount1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_p_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_pv_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_m_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_ipn_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_debug_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cp_transactions`
--

INSERT INTO `cp_transactions` (`id`, `txn_id`, `item_name`, `Item_number`, `amount_paid`, `user_plan`, `user_id`, `user_tele_id`, `amount1`, `amount2`, `currency1`, `currency2`, `status`, `status_text`, `type`, `cp_p_key`, `cp_pv_key`, `cp_m_id`, `cp_ipn_secret`, `cp_debug_email`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TYooMQauvdEDq54NiTphI7jx', '4eC39HqLyjWDarjtT1zdp7dc', 'Merchid ID', 'jnndjnhdjdj', 'super@happ.com', '2021-03-11 12:46:45', '2021-10-07 09:42:44');

-- --------------------------------------------------------

--
-- Table structure for table `crypto_accounts`
--

CREATE TABLE `crypto_accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `btc` float DEFAULT NULL,
  `eth` float DEFAULT NULL,
  `ltc` float DEFAULT NULL,
  `xrp` float DEFAULT NULL,
  `link` float DEFAULT NULL,
  `bnb` float DEFAULT NULL,
  `aave` float DEFAULT NULL,
  `usdt` float DEFAULT NULL,
  `xlm` float DEFAULT NULL,
  `bch` float DEFAULT NULL,
  `ada` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `crypto_accounts`
--

INSERT INTO `crypto_accounts` (`id`, `user_id`, `btc`, `eth`, `ltc`, `xrp`, `link`, `bnb`, `aave`, `usdt`, `xlm`, `bch`, `ada`, `created_at`, `updated_at`) VALUES
(1, 17, 0.99928, 0.00175792, NULL, NULL, NULL, NULL, NULL, 182.225, NULL, NULL, 0, '2021-10-31 12:25:53', '2021-10-31 12:25:53');

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `txn_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_mode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan` int(11) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `txn_id`, `user`, `amount`, `payment_mode`, `plan`, `status`, `proof`, `created_at`, `updated_at`) VALUES
(33, NULL, 17, '11', 'Bank transfer', 2, 'Processed', 'Zz7q7d1.jpg1621426025', '2021-05-19 11:07:06', '2021-05-19 11:07:34'),
(34, NULL, 17, '30', 'Bitcoin', 2, 'Processed', 'vl9TeR1.jpg1621428007', '2021-05-19 11:40:07', '2021-05-19 11:46:49'),
(41, NULL, 17, '500', 'Credit Card', 0, 'Processed', 'Stripe', '2021-10-11 12:32:32', '2021-10-11 12:32:32'),
(43, NULL, 17, '500', 'Credit Card', 0, 'Processed', 'Stripe', '2021-10-11 13:10:47', '2021-10-11 13:10:47'),
(48, NULL, 17, '500', 'Stripe', 0, 'Processed', 'Stripe', '2021-12-07 08:35:29', '2021-12-07 08:35:29');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ref_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `ref_key`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(1, '8yZ6FC', 'How can i withdraw', 'This is how to withdraw', '2021-03-11 14:31:42', '2021-03-11 14:31:59'),
(2, 'ApbuIF', 'How can i deposit money', 'The deposit of course do not hinder', '2021-10-27 09:41:31', '2021-10-27 09:41:31');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(255) NOT NULL,
  `ref_key` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `img_path` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `ref_key`, `title`, `description`, `img_path`, `created_at`, `updated_at`) VALUES
(8, 'DPd1Kn', 'Testimonial 1', 'Testimonial 1', 'SIu0JZ01.jpg1635329714', '2020-08-23 12:24:52', '2021-10-27 10:15:14'),
(9, 'ZqCgDz', 'Testimonial 2', 'Testimonial 2', '5EJXRd02.jpg1635329727', '2020-08-23 12:25:07', '2021-10-27 10:15:27'),
(14, 'b9158B', 'Home Image', 'The image at the home page', 'b9158Babout.jpg', '2021-10-27 09:48:42', '2021-10-27 09:48:42'),
(15, 'iAwfKe', 'About image', 'The image in the about page', 'iAwfKeabout.png', '2021-10-27 10:22:20', '2021-10-27 10:22:20');

-- --------------------------------------------------------

--
-- Table structure for table `ipaddresses`
--

CREATE TABLE `ipaddresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2021_03_09_142220_create_sessions_table', 1),
(7, '2021_03_10_082445_create_admins_table', 2),
(8, '2021_03_10_082519_create_agents_table', 2),
(9, '2021_03_10_082715_create_assets_table', 2),
(10, '2021_03_10_082817_create_contents_table', 2),
(11, '2021_03_10_083110_create_cp_transactions_table', 2),
(12, '2021_03_10_083324_create_deposits_table', 2),
(13, '2021_03_10_083400_create_faqs_table', 2),
(14, '2021_03_10_083510_create_images_table', 2),
(15, '2021_03_10_083557_create_mt4_details_table', 2),
(16, '2021_03_10_083627_create_notifications_table', 2),
(17, '2021_03_10_083824_create_plans_table', 2),
(18, '2021_03_10_083850_create_settings_table', 2),
(19, '2021_03_10_083936_create_testimonies_table', 2),
(20, '2021_03_10_084009_create_tp__transactions_table', 2),
(21, '2021_03_10_084031_create_upgrades_table', 2),
(22, '2021_03_10_084120_create_userlogs_table', 2),
(23, '2021_03_10_084140_create_user_plans_table', 2),
(24, '2021_03_10_084235_create_wdmethods_table', 2),
(25, '2021_03_10_084300_create_withdrawals_table', 2),
(26, '2021_04_06_083043_create_tasks_table', 3),
(27, '2021_04_23_110006_create_exchanges_table', 4),
(28, '2021_04_23_114622_create_coin_transactions_table', 5),
(29, '2021_04_27_080945_create_currencies_table', 6),
(30, '2021_04_29_110349_create_c_withdrawals_table', 7),
(31, '2021_10_07_112653_create_ipaddresses_table', 8),
(32, '2021_10_27_114829_create_terms_privacies_table', 9),
(33, '2021_10_31_131124_create_crypto_accounts_table', 10),
(34, '2021_10_31_132849_create_settings_conts_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `mt4_details`
--

CREATE TABLE `mt4_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `mt4_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mt4_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leverage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `created_at`, `updated_at`) VALUES
(2, 9, 'This is a new mail Victory, kindly apprehiend', '2021-03-12 12:38:30', '2021-03-12 12:38:30');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paystacks`
--

CREATE TABLE `paystacks` (
  `id` int(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paystack_public_key` text DEFAULT NULL,
  `paystack_secret_key` text DEFAULT NULL,
  `paystack_url` varchar(255) DEFAULT NULL,
  `paystack_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paystacks`
--

INSERT INTO `paystacks` (`id`, `created_at`, `updated_at`, `paystack_public_key`, `paystack_secret_key`, `paystack_url`, `paystack_email`) VALUES
(1, '2021-10-07 10:26:10', '2021-12-07 08:24:59', NULL, NULL, 'https://api.paystack.co', 'victrinhoj@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maxr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gift` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expected_return` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `increment_interval` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `increment_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `increment_amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `name`, `price`, `min_price`, `max_price`, `minr`, `maxr`, `gift`, `expected_return`, `type`, `increment_interval`, `increment_type`, `increment_amount`, `expiration`, `created_at`, `updated_at`) VALUES
(6, 'Standard', '20', '20', '20', '40', '40', '0', NULL, 'Main', 'Every 30 Minutes', 'Percentage', '4', '1 Weeks', '2021-10-25 13:25:08', '2022-01-07 08:28:11');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('0WMQSJKvjtMSw01qKweieaJiGCaIJvpyQuaYbhxa', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTmtYSFZOc01NNXRQVDVvdmVQQ3pRNjdtVDl3cnRtS3p5OUpZSWlMdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642554613),
('0WyvsuIJLuo4N0quXifDDWUZCx5YEPdbeJQL6DbO', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic0ZEMzRQbmtFVUVDek9LcDVVQThFTHdyWXJReWNONnBQNll6SExrbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642554908),
('1SyZJjbVhkYy3x3MGXH0L7rWxHZle1Z5A2Kly8OM', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlBoR3FHN21uVHpMQzFaejB4ME50VExMT3NxV25wajJ6MER0VWpWVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642566026),
('2FYt3WN1CMD54ODrHqZseTKTaPmpNjSWQsjGzgLw', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVElBSGU1Tm9pSm12bTFtbjBaQkdRN2RlQWhvMjg1ZXF0VDdoZnpSZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642575926),
('2YY7DUhjq5NJQs4hNqPS6Lg0LMy0R4uQYOpPtlT1', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHVWMDR0eWtUQktYNmEycVpZWllncnFvWnZQdE5oajFhdFF5REY3TyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642563936),
('3PWIcznBTd5MePgm6ZMWDm02yaDpzOVhKHxlX51K', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkh6eFZQdG1qRGpLQTdRZWgwbzNYY2s5dnZBTlBvdWRaUDE0b3JlRiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642560336),
('462pLDdO2pUeeemvzc8scMuVnyE7D4S0yCaVWbEs', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRldPSVoyNVRUb0hvOUE2RndORmpvek42OE1SRjEzNHRlaERKbXdyaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642558830),
('68wnTYGuGKDL3sWBZ7vBPl6enNkTiFGxXksDjGmD', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUxNcVhpMHlmWHFCYVF5ZGVsOTk4SFpWanQ4Tmd1OGhtVHFKNm16NCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642574702),
('7BiVx3LI8aUuvvBqTUOEKMnfCIDaywtI0wvJSOzW', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicXdIRDJEOHhiMms5VDEyMFZsMWFzVTVoZG9uVEF1bDBwcm1LUFhWMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642563016),
('8n8GvaxNgIfjQZ70z6L4PL5ODbk4vwB4MV4hLSYc', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNUsxdTlkWVYyT2wycVpQWFNmR1dJaW1KNTFzcnBlS09UY0Z1dThzOCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642580116),
('8xoTbAeCGelwDjhXVIHulNlumB7LQtm9zr9zw35E', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnVmMEdyanQ3OVRBWk01aDNzd2x1R1BLbTV3ckpnbzRoUFNhamQ1dCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642561218),
('9tuRypLHCQzDxutYRHloNH4doe4V6Vn5jECa2LbD', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQjloYk5Mb05BZnBHbVBjSkdOT0g3SDIwS1M2dG96Rmp1N0RtNjhUaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642555848),
('A1lF2OSWQQjiM38wREL65p3sgXjh2OTCeQ4gfrPk', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidnluc1JacXJ4UkM3RjhtUGdrdlBWYnZtM2ZCOXRQRW56QVg0WTZQTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642569640),
('A8ve3NhnfP27zqvpHt3XYsbKT2onCRbsfDvOcM9Q', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFRSdjVtTlI0aEM3V0l6MndjTEtZd3QxcWhoNVBYRVZEaHRsYU14QSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642547712),
('ATSZkwowVtGE5W2iVIMwQuCLFKrucBgiKlQ3i297', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieGgwdmVBQW5EamJlem5obGFzRk94NWZZRG9JY2FFRzAxbnZXcGdEViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642568438),
('aYNAdPjXCRQssPtID8wxrjTnu9tRukK1btEqpAt0', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiME04WXllRTE2NHpUOE42Wmh6aGNYdmdqa0lsQ0xVd1pQcVd6bDE4aSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642577441),
('AYTcj2jVAw2AugsNVp4PvF1hpa9NJkvtAQB6xRXy', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV1VTb3BXTVpsYkNKeGtESVdRdHdsQzBqSmtRYW13Wnl1NFJIaktJRyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642579510),
('b2zmtndGyfUgKftjab1yOMfazvge6qJs7v24hpAk', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUDluRDh1OHJ0eW11V3k3WExzYUZmUlkzTHNlckhuU0RuTTNVa0puSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642551320),
('bj7ItNQGPNoibNaVY6RHZxsg7QaBwsUAtDcazV1L', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoickp0dUF1RDZudjNsRDFoYUdwVlA0dnA4V3IyeENDMkhtOTlkakZHOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642578307),
('BlgORNY0fnaC3Kh9WzEZfMbnJulbfg8NF5R6Jek4', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT0NpYkh5eFJOTGh2S3l2SmxmcnhFSldsNTV5TTNhaWJrbEk1cDhkdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642554342),
('BZBUaoBL4P8SB9ePwH2OfIq6q2I05iSslktn8Yp2', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZktDWDNJYms0dFE4SFI5d2VkSEVJSXFFTENlekhGa1RqeTZLeDZYeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642572909),
('c2H7FzlDP4sFshXIcLu9hct10sQlyyy658mChLGj', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1JFcjRkbWJtREdIbHRKbjZ0OXRuQ0JZV0NQNFF1VVpJS2FieEN5USI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642561818),
('cGW2uyCGa28zzITwh4E9eDdpySRpZx9LiAJh9fpC', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYWEzNFNNNkhoRUtwVkZZTENleWF5eVNhdUN0RWVlaWJVMFQ5Y2RiaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642562433),
('CIxCAXEhWJsBCf8HPHf91SGAzwbsvskLKn5OHRuh', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRktNcnRMMXJJa2kwVXRacHpOc3JUSzRSUWxXMVRpR1R1U3RicElXTSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642579216),
('CTeKQfYWxbH9uqURxSw7rugakxS3Z9atFrAy6Xv4', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicUFISnRiYWs0WG9KcXNKZ0FoMncxTHR4OENzSDRybVBhMXc4SjBtcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642556717),
('Cy9aEYgUOPoo4ZcAU1L46VzpgSoYmIbzud0FFwaE', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWExZUUVDOFREYnRzWFZlRFdmRkhSTHE0Sm1YZ3B3NlRqM0Z3VEpaOCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642574438),
('CzWK9wFonAmn6BzIpBpOT3scrkP63iCrvXPfczla', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYXFrZUN3SlRvRDVHYkZpRjBhNmd4Y25JZGVKcGo1TW5OOFlUSlBFeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642577713),
('DpKLgutU2GHoYfEfVSH4J13x1PajAynVsiCmzV7E', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoib2p3SEk5SE1YOHI4SW1iQ0pLbU0xYjg0QXVockZ3OWFjQU1nbm9XViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642573547),
('E0DfzXsl5mKH5D6VeSoDelQSglsrhRKc097ZXtsp', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTM3bE5rQm0xRUlFRlJHR294SmVmUmNTNHZlUUdXaWQ2RXpLTFFUQiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642551924),
('EC3O3AojL1xJJjz6tT2FaCw7QzVRivnHU8LXKXOD', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGdhSVdsRzJ5Mll2OTNYdkhoeWFObDhCbWo4QnF3TWpKY25PYTlZViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642578936),
('eCMMevhB3N292gpySJqUMHWfqgOTQrWaJ5BnLqxy', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicHh0a0dkR044SnRZalhtM3BRMGVaQzZFNWVCOFBCeGtlZFpFMVpZZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642563319),
('eGTzvzqcFyUEJo5cd6jmOQLp4bJruAHAoSMjJxRy', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2N5Z2pQdUxHM0dhcDdFMU42Ym44Q2g5akpmdWdoTFRMa1B6VWJ6diI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642553748),
('eymJvxwlgqjeOusP9caCr0SVueBGMAVkgg2qKHW8', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWjI3eGUzcEpaMElIcEtxdFh1bWJXcnNuUHZKbGxvS0t5QW9IV1VDciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642546834),
('fbCAD8Z8TfCMnAi5qZh94bhxdLp5F7n5eON05QBl', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTGlVZW00UnBOcWhzWFEyaElqZjlxV09lSVNDaHFUMTJwdkhERWo5diI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642570843),
('FG7L4VJHyIx3vhDo4AM97OdMHwBA6mrSuFLzz2y0', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaTFycE9uN3lRYXRjbkNaaHZ5WTVmaU1pZHYxU1RmYWpNUUtCYkp6cSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642573825),
('fo5EoJ1muxSK3X8p6iW35XOWLfDcQdYSub4ks9VP', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkl6bkwwQXc1WXBNenlkRklTb1FjVER4bHRMNHp3SFVGMmhKcHJ4UyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642562111),
('FzSeAk2j3Lq2mozqqYtPzLjM1C7HZfeOnZRFjT4B', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDJMOE53NUNlc2o5QmMxY09xRFZHQ3hKd1VlMEpnUkxLejhRdHpQaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642569924),
('gdVtNfzwOeR2sFb9aWYBWLQGaSJai639ghkAEd3J', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTmxFcDdQRFlmeWZLdzZ0VDZ3cm1CS0ZUSGVQRDFieVdmR2FoSmJScSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642579814),
('GMyJ97BP2V2hvIvQ3yKho5oPmE6geWcWIeONJ6jZ', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV0REMXhOSXBwQWtOcW9lZjBBSkN4bVdGM1haYlhtYlJwWERWMkthSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642576508),
('Gy2U1HVfpMTauaH8W4R6oUtrUDbnjz51FATfnyDZ', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkx5MGRJdWpKUUs4ZEZKdENtOWJTYTRMV1g1NEZJbWxHU3lsa1dpcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642568716),
('Hmjn9RfCxt46W63AgJLiBKSdEWBoDT1K7TTU7uur', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR0xUaTVRYU13WDdodzVoSjRXUGpyVnlZcnUwa2FyaEw1NlFwN01aViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642547131),
('hpDgNnqTajbCK3GasSCnTlEjMgmh0VMSGlb7O8Dg', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYUxyV00xMlpDbUxST2FFZUo1R3NybnRrQkNWYmJJZUJxVHR3U0RZcCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642555529),
('I56cpZXg0CLRDGzADk7K6WjoDxNPuO12y0M94OBr', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWHhqV3c4NU9CbFBua29pZzV3TWd1elNVbm94MHAzVDdLdDBOemU1UyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642566331),
('iieE18KSan18ZK3SqOLXSetEN3dVshf6s6UNWIFg', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHppeDFXd3pRbExFYkRDZjJNOWRPdTN0cmw3YW9CclRveWgza3d6YyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642552809),
('IQzOa8cpp1GQVrajrxIFOkggz6p8m8N90X4IYMlJ', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVlxSExpaktoUmFHMkJjc3VpeHBEZTF3TUZ0NUZIdWUwUTY4R1RIcCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642571707),
('iTb6n8DHyQJsivu4EoAMZ4gqn3UwS7By98q39n5i', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNzAyVjR2SlRUR0YwSUxUTjg3bHJPUU9JUE0zdmZLWTlmTGVZTjFMSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642577128),
('ItKVCHmpK1KFkeN7RbgxwSHWJUM1YGNF1jkNsnxq', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2xOTVdCWGdFejJPeUl4aWdRNkF1SGhtMGdsbFZvNVhQNzBLeDRLbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642570551),
('Iv3TlXKP7YGLgdjLJIuCmEcgUjHbmMHqqj6fJUCp', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFJYMk9abmtLSFZTWVNaTWhxdW81SEl4Z0tsUXE2Znd6SVhDMlg5UyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642559147),
('jhxTCVPTb5e7oenUxXPS084iPqnJsW3GxLLsWZ46', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNU52WlBPVkhrS25lcDBRNDBmY1BRT0F0Q0NYSzd6ZGxkQW5IcElCWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642573210),
('JiRy0MvnI3gL3LGpjidzG6jDIBIIEEbsZm3JMkm0', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkJKU25IQkNqNXpIZ0FPQkU2aFYwUTU0dGRCZXJ1Nk9HQ3BaeTNPYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642547416),
('jn8IA4jev4cwMeAFutVxB06x5ADn5PhzUFArTDpU', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQUlNT0tEVE9CTTloZ1RHSll4VEY1b2d4dkNscFhxbVpjM3p2QkdIdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642574124),
('JzhEJCkANRTEEFrCDXJGIdWmJgHpgRtzka8l1gkq', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVpuRnJpSldMbHlBVGNmUDdwYW9uQmNEdHlQWG02d1RhZktjVlBwdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642572606),
('KliDy5PGVWPJ41ntwg7u9eijGujaiLTA2TUDdVfz', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVZxVVROSHg1RjVlNDU1ZFNSWThGOGJRS1pDTVhOdUl1eVNZV1Z2aCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642562725),
('KoQ8JktfGWezkPrdRkyPgNYvGgywhygdE4HVXHsl', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibTdoTXFqcUV3UkdyaWhNVzV6MFFoMzJhUTVqc3oxTjJCVWc4SVl6ZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642551021),
('KZqDouYss0Cuv6ccMJzjthjKnoK2rthJCZ9pwecG', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicmpyR2FYOFZVRlc4emxDOUhqOXRtdlNwZ3k3VWh4eFBGdzF2NWg5TiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642551638),
('lCZQcpxeaOOxbFkaSqzrISKbijgKK0P25TVOydrU', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibjFpWWxLaHBUSTNzR1VjU1dkbHczeWpLTTlXUVZ4eDZHZWV1TTdXdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642549827),
('ldZFD7IsOYo8ZB809Q6t5fFTBE15ZvwvKV3CdXEz', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibHduRnFsYUtqa1lnQVg3UHM5cTdDNEhLU3RybjluaVVtMmdZWW84NCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642568133),
('lL2Srx3bhVaiAnQ8cLBSPlo53CBatUCRy1OTLuUK', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiektWb2hoRkdtbDFQZlRSOUY2NmVEQmxiZmcycmRIZ1JyU1VUWjhacSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642557337),
('LMrYpSwAhJfR5G6Gz5PKiUujwzGhuK8IVI75g7Qs', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMU52NksyeHpEZ1hrR3Q2eEF6OWdxeDJQTUxSOWZZMTBwQ2VPa1NFdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642548924),
('mmQpJiunba4lXc0bBU3RQQWgcqsEpTmdQ376cbOf', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicHVRUkI0S2lPR044dm1JeHNVUlVlZW9QY29YNEw1bDh6aHJ5bDhrUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642567519),
('nAkr0unfUnFQPM7atdFVF5KHrU2ZoWcGFvsUmD5M', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkFNOUFaaE1aQU9zcjNqNUhuajR2RTl3VUN6MWFMdWZDaW1naTlUTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642564841),
('nf9sb041T6VyKH6rLSOorPpEbFSJUujnJA8nhNGm', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTUd1Wjg5UTdNZUdSU2VoMUZ6dkNJT21ZWVpOZWltaDVZckd4cmtudCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642558514),
('NP3meG7jxoPdpTcCPWtkNzVFGxh9RAvbZV1a0cYV', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTMxTHhoNld4Mmh6V0RtMDZoNkhPb2MwOVZVZTBJVGVrcDRrRnQ4NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642578010),
('nVLvq1OYxiMOpGe0uQM2oD3efU83g1v4MivaJzwE', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY1pMZDB6MXBGMlNpaUFyeGpMYW9VV282TWFueHlYbzV4MkhKWGZVUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642563619),
('nWSvGdwbfEDeZJPoeB4pfpLj5T8eBwMv5x3QsPbQ', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSVdKVFZuWjFpQ2M0dzZwUUM2RlFPY2hVTXA2ZU1LS0xBQlNKOXNmMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642561547),
('o5hz2oNdd0yRrf2cxC1awn53PRZAmPvKl5Ksgpdz', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUMyUkh3ZjdTb3o2d0FjTEQ2OXFKTXpleHRJUnFKU1YxT3k2dWtsZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642576838),
('o67mOtcIGMkNFViP7iEBKZb51nmRwmwqO1a1z3oZ', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMjVFc1VVVzM0UUlTRkFuTGVaR0VkRWt2ZldJN2hWeWI4VlVTTFh4aiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642556126),
('oHavRaIoUHQWErc3LEjCRqOWllil10m2pB33co3b', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic2ppQVdKUVJxZ2lBZWkwM056d25xZWl4dXZLbmFvVG9sUnNpV3dYdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642550102),
('OtcyERu0WTh3sKC2CYIB1mE0pa1PoMEA7hlx41nk', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkUzZExZTXp2N09ycHUwaXQ1eThvN2ZzNzM3MlZOTkw3MFlDdnp1eiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642565741),
('ozvu3LZl66cxqioRi2KlB4buTYeElT39xvMUDBaO', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiblBZdFlMVzYySEFwOU5FN2FRQXRwSmJrbGpVdXJKOGc3SzFOZzNXciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642560624),
('pKXNoWUcDcWMXm17U5UwVnCCTdXGz99WteRDaEY0', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMkpPUWJsZDB2Z291OVdQMVgzdVowUFVCaTRnc1c1bHJJTFk2VFlKSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642559733),
('q4cHbd84zotlyNjD9YCQ8vsqMhFt7UbAJM0iQqhz', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibTdVbFY0emFKeW12S2h6cmJlNnFVUWpXMzVpWDRrMEdnWThyalNvYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642572013),
('Q5cfkp3oim81dMa2V1blc4HCD3p2TZOaaacU1FwD', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS29rU2tuNGJPWjN5Y3d2clcxajlRaUowR1NoTEluSTNvWFRkQm11RCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642564242),
('QhLSKvRjUwaUMmKNH0bOAm4Yxnt7yNzEUXA7SQ7U', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1ZnTmR5RUdnZDNWa2tIeTV2Wm1TVVhaYXNSbFFleHp4QWJCT3R2UiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642548324),
('qqVlmZTk6EOo8cijMbLcF5SMaroJz8TrG6uTap8F', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid3M1VnZRRXllSk5iYzNaSmxNSDVwdG1UNFJnQ082bmhUOThObWFGcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642553126),
('qVUTpI8F63KkEQvtvr4VC7He43VlhQpvuj9ZDr76', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibzZIRmpMb3gxUGU5cWdwaHBaazA3eDRVOTFpclFmeFVhN01xeWUzTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642566938),
('qvvIYjefPM1CbTtuEKMVlimznvD49X3Bmp8Bp4Wb', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTmREenF3YlJWVUs4ZE9kM0hKMkdGWnBob29hWGFVRXp1SXpONE9RQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642580414),
('qyUVlWSspcUAcnAQaqXlHOEpqIVlbqOvrKN2LlKP', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNFQwdEVzUGtYVGl1cThYaFhjQ1VnZlpEN2oxOVVsWUplQTlXVUJlbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642567226),
('RL6ULgc2JWSdNyH5KR3PrHZT9d8ukHhviA6KlCD7', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQll5QVI1N0RzajBhbnZwRm1KNThRNDFrajA5OGNqN0l1b2h1UVFtZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642570218),
('rWIdyzCvJhEcSjfhLNFn3cMTDdW1yWwRj87mP8U5', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoialQ0TkVld3FSOGVIa2ZMWkU3WGJTTzZsRzNuaTBUbzk3QUN6MXA2TCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642571440),
('RZGFrTC7BxDkFeCYV2Ug5ARFJSzRuI0fMpKFEodl', NULL, '105.112.117.112', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUGM5R09BdHp3QnVMZXdGQ09Wd0lpbjZENWpJNE9GQUFiMXJrcU5USiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovcmVnaXN0ZXIiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1642580180),
('S3HQrrev95DNo5SLrpa5Q6nyfVWwxp9iSHObewht', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ3JST2k1b1V3NjlqclhVZnlHOWxrNzNUWHVLSXhLdDZlTzZFSndnWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642580738),
('s7wK21TowuBIx8tpEJXPIjGpaUsAHAOrekrYMMpK', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFJqYkFVS3NZdld5T3BQRmJ5UWpZdTNPUmF4aFpEdHZHWDRIOVRsNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642549231),
('T6iJo8th0mdjVouj4iNBJWRq0l7wdiYbC9npi2NZ', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidkVudjAyZndJWDRmTFljcWl3YVoxd1dxTm1RNWRSMmIxVWE1T3ZOTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642555229),
('t8ukCW584zOClNcGDbfJjo2xGTEUnGTD2CaLBWG3', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiajhYODBKUGx0cWNnQTc1Wkt6Nm9KTk9mcHVhQThPSkFQaGFHRG1SSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642559434),
('tgKefxm1dR390pSEa0RSpkcRtcY7Q4TUJblKhcwa', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMWlrM3pMMmF2bkhlOW5hemgyMVRnVkoyb3BENDhjeGhYbDEyd2w5MCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642578647),
('tpKvP2ceHWdayU8aoPN0WEPBmZPlFCnEYjOAyEEE', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzh2RVAyZ3VCVVpNQzRnR2RvcDJOY1RDYXR3WXBhRFc5bmJnSkZLUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642548648),
('tpzQXch62xpT3ZyGP0gpF3Yln9QkG7mtEhAhfnED', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNHJSTVR6YmZ2SlROQkZuaXNmbVNhZzBPSk9jWFJOeGxRcEdUY2tBYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642557011),
('tvGbgmAY8yVgXbmsxnAikKOHhBDFvHn0oQNHixwo', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRFdJamVYbVowS1ppd0t3RGthc0pjTktabWZKcUliN3drb25hTVBtZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642566628),
('TXJKno1QreTlXEcPsSwRerdUdvqI27yOvoiBgBPt', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVVPU05qaXJyWVZnZDVaYTNxT3FDN1c3RUZkZnIycXpCSU85aG9uNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642553441),
('txUFMtJx9s5LH2BLUYekUCi2Ygqc6LWwpl2Cu03f', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieEhnZEhvbUEwdzR5ZHpsaks5elpjS2Zoc09NdHU1SkhFZ0FXVlE2aSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642575050),
('ua9FvxmmTAuI5XWP83vxpyHDnrxibIFFp6l6bPTy', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSDJYZ24yN3dZam5LVEhJWWdVNVF3WU1xSVcwVU5zV2VzYm5CVW9RZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642550732),
('ULaEHjJH4C1oWCrBkSWqa7lcXyWEYqKXPL15kfEv', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaDRZaFVKOEdSbmxHdHZBbzhrWkFycm9va0FLQlpmMzZsZHNqWmRLMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642565415),
('ULRkmwX9r4ZY4IsnhwxlpksejkX5Fw2rWLfLV2hw', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOW9mNHRiVnh1MVR3eEVEbEhmdjRSRnlzVzRkMDRBZmJYYmE4OGhmWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642567809),
('UmPrZC8wvWImVDU4C7UBJcnVwsrEHIyMV5G4ZeQp', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQU1DWVZWR1UwbDdyREVYQndTVGM0Q2lBTlh3N256VTN2VlphTHVwZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642549530),
('UN4zCtubH2xkZAHlr8H36zhmPWCBy2NFH3JLdFxd', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlpTTkE3VHZtSmw0aE5ld1hYbzVXMFUwbmR0aVcwYnV0MTZsUDBqdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642556412),
('UsxfQjA2050d8XsSVQYEuCXsEqRm6WVsnAyJmNEb', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZk1rMmp6UjBHWnBjOExrNjU3UHQyOWpsN1ZUYmVSZnlSN2lKbWlEcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642571136),
('v2R3n2eAkXktgLTlqqBCPjp5twrv3HbUeD6mw5aE', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkIwcGZKOVBwc1ZrZmxJcEsxVjJRMDRuUnB5SzRwTVZhOHpjS1NRMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642552511),
('vACMR4ea6HJgI5xOzVC54Sjb6NXLFNkbosb4mCcT', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidTMxeTYxTEtQYkFHRE5LVGpjWlhTWkkzQmtFdEdmZERwVnNjaE9wVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642560004),
('VQsSLFhoSg6ZrryznjzYtDQWi022z5LkUMjCFIHk', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWVhjN3JNeUhGZFAyUTNhOHB0QjVZTHlPaDlibkNLSWdCMEtzZm0zciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642550414),
('vSdLpOyuiMMR9srTfJdMRVUu8dsOS1EWZtvcv82t', NULL, '73.77.234.255', 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkxRSjdqc3Y1VEtDeXRmS0MyVEc2eG15WWxudjAzeE03ZFV1alZmZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXoiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1642546899),
('warthizc5Za3Wdc7hRRUblcoebmNarxyummJI7Fa', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibnIzSE5PUDQ5SDludVZCaFk2TndGc21YcWdtMDJ3Ymc5TFpwaWVocSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642558230),
('WBoVElRfOlmbnh7hONCZtSj3VXSaahTbGxHtye4E', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ05ENEZJb3hPZHE4V1JRNUNhUFQycDBPb0lyS0M3R3dFSXlVdnd1NCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642557932),
('wHckrddk0apC5xTE7y1DBdisQtanjZIzJiV02EkX', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2luM3ZWNFF5SkNlWUJmRGpZUkV6RkxCODNPYVRxRFYwNG8zcmt1WSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642569314),
('wT9VcVgkbnm5vSZoWLQfREqmMRM6xuY1M5WkBnQZ', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidVM5SWhGQ0Roa2JMWEZCMWNoaVBnT2lKTTFpdXdRdFZtbjRzbVJCbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642552234),
('wXEETK7ByXtjiHITO9fvLXejCAeFGfTloLXfUhOA', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUlB3bDJJb1RXaVRnWUg4czdlazJ5ZnYzMTZERWc0V01rSFR6N0s2VCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642576230),
('XeyOPullu42Yg9IlwQHtYD6AE9r3Lh62yVZhOBoh', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicUhaQ0NXZ2o5YVpzdDNmNW1OV1ZacUp5Yzhnem4yall1NTJFVVVHbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642575646),
('XIUPAOBGs8S06m7Wk6uEqKwiz47WCcepxE7GWl4M', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYzBxRTlEZWZGYUMwUTdKMTBNTlBPYXptMUZiRmxTR0xTUHU1OGhySSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642575320),
('XNHPlqB8WhoTyNqRcDZIQ2iVM3tknfsTs3A1PdOI', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUdTNWpMUTFFZlkxWDRISHpjdWFpVDZJanVOM25lT1lKUFhMaVZjciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642569027),
('XtBKqtQJndMW6hMSjugqoFS1o2kgW4T7RkvZhbKP', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVzRKbDlXNVYzNDJuVW1ZZGx0RTFoandPYWF6OGQzampIZVVKM1hzdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642564548),
('xtd4Aa3QeByG1L5YDXKRIn8Y81w4CWSP69aXkB6E', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1VVSm4zYnhIdTVwVWh6elFVU2ptT3BaeGRtS2FteHRWS0ZFUE9UVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642554024),
('xxfmDD27KYiNuetILwcNDdNru6exeoUlR59j7yG5', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZGJLQ0ZZalNJUmIwd1JobGVvZVFrazhMb3RnMFVLc0k5ZkdRd1VZSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642560931),
('YezVdqiNMltkF8RkTBQrNlVcQluxscAH4OOFGRFy', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYmExblp1TUFpRHJQVElVWlpuMjBvc2hmcjh2b1ZMbWhwV1d2Y2JqOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642565127),
('yopyrijRS2w1PTXKcpqDas6R4jQno0t15jLci9ZP', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTdZWDlPVGZlTUxaamhraFl4TkYxN21TSEhRNE9qbzdoTGw1ZWM2QyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642548039),
('YRJv2ZgPBvOgeEinPlUOfvPcUq6FYksbENkbvWjT', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT01rUkEzNjdsd0s0Z2dOOFExV2R3eVFuVHRJdTVzZ3BscDhEUDJ5cSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642572330),
('zHGX3pdHHmN0yvhR31gu4sEB8nylYOY7ECAKLQVl', NULL, '198.54.116.212', 'Wget/1.12 (linux-gnu)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibkZTcDhWbEx5TUlVUW5GYnE2NkVqNDFwY0RDcE1VQlozOFlIckJZRiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9vY3QyMDIxLmJyeW5hbWljcy54eXovY3JvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1642557618);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capt_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capt_sitekey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_mode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_s_k` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_k` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pp_cs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pp_ci` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trade_mode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_translate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weekend_trade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_server` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emailfrom` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emailfromname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_host` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_encrypt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_redirect` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_commission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_commission1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_commission2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_commission3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_commission4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_commission5` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signup_bonus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tawk_to` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_2fa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `enable_kyc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `enable_with` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_verification` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'true',
  `enable_social_login` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `withdrawal_option` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `deposit_option` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_option` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_annoc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_service` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `captcha` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission_fee` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthlyfee` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quarterlyfee` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `yearlyfee` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newupdate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `description`, `currency`, `s_currency`, `capt_secret`, `capt_sitekey`, `payment_mode`, `location`, `s_s_k`, `s_p_k`, `pp_cs`, `pp_ci`, `keywords`, `site_title`, `site_address`, `logo`, `favicon`, `trade_mode`, `google_translate`, `weekend_trade`, `contact_email`, `timezone`, `mail_server`, `emailfrom`, `emailfromname`, `smtp_host`, `smtp_port`, `smtp_encrypt`, `smtp_user`, `smtp_password`, `google_secret`, `google_id`, `google_redirect`, `referral_commission`, `referral_commission1`, `referral_commission2`, `referral_commission3`, `referral_commission4`, `referral_commission5`, `signup_bonus`, `tawk_to`, `enable_2fa`, `enable_kyc`, `enable_with`, `enable_verification`, `enable_social_login`, `withdrawal_option`, `deposit_option`, `dashboard_option`, `enable_annoc`, `subscription_service`, `captcha`, `commission_type`, `commission_fee`, `monthlyfee`, `quarterlyfee`, `yearlyfee`, `newupdate`, `created_at`, `updated_at`) VALUES
(1, 'Online Trade', 'We are online', '$', 'USD', '6LeFiYEaAAAAAPWZh1eQgdd5W99qz8KXZEEmCFaK', '6LeFiYEaAAAAAHmnxl4z7s9IH1-TmmCu1mD9Mn_8', '123567', 'Local', 'sk_test_51JP8qpSBWKZBQRLPWqHkFM8oqFEAqXLAaH3S8byZF73X0UycxijVyfebcyu6OVoZ8eeAelr3js3ADYIGU22Dk2Vo00kGkdE9xP', 'pk_test_51JP8qpSBWKZBQRLPUIfQVYfUGly65fb1LiPUwAUajKy1nVM9Rvly3v3hQLvXnRqrWCrnUNz1qPQHNSxE689tSAoL00B1iOTNfd', 'jijdjkdkdk', 'iidjdjdj', 'online trade, forex, cfd,', 'Welcome to Online Trade', 'http://127.0.0.1:8000', 'upload-logo.png1617292120', 'upload-favicon.png1617293031', 'on', 'on', 'off', 'support@onlintrade.com', 'UTC', 'smtp', 'onlintrade@happ.com', 'Online Trade', 'smtp.mailtrap.io', '2525', 'tls', 'c1fc6aa480f0ca', '37cade45cfc7d3', 'OTUW0i4B7ZI-GaoNPwe1krPF', '807575122053-0056a75lgfai5f205sc0fvku6tqgd6ac.apps.googleusercontent.com', 'http://yoursite.com/auth/google/callback', '40', '30', '20', '10', '5', '1', '0', 'tawk to codess', 'no', 'yes', 'true', 'false', 'yes', 'manual', 'manual', 'dark', 'on', 'off', 'false', NULL, NULL, '30', '40', '80', 'Welcome to Online trader version 3 with a lot of Security Features', NULL, '2022-01-07 14:03:59');

-- --------------------------------------------------------

--
-- Table structure for table `settings_conts`
--

CREATE TABLE `settings_conts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `use_crypto_feature` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'true',
  `fee` float DEFAULT 0,
  `btc` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `eth` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `ltc` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `link` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `bnb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `aave` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT 'enabled',
  `usdt` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `bch` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `xlm` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `xrp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `ada` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `currency_rate` int(255) DEFAULT NULL,
  `minamt` int(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings_conts`
--

INSERT INTO `settings_conts` (`id`, `use_crypto_feature`, `fee`, `btc`, `eth`, `ltc`, `link`, `bnb`, `aave`, `usdt`, `bch`, `xlm`, `xrp`, `ada`, `currency_rate`, `minamt`, `created_at`, `updated_at`) VALUES
(1, 'true', 2, 'enabled', 'enabled', 'enabled', 'enabled', 'enabled', 'enabled', 'enabled', 'enabled', 'enabled', 'enabled', 'enabled', 500, 50, '2021-10-31 13:32:30', '2022-01-07 14:03:59');

-- --------------------------------------------------------

--
-- Table structure for table `terms_privacies`
--

CREATE TABLE `terms_privacies` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `useterms` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `terms_privacies`
--

INSERT INTO `terms_privacies` (`id`, `description`, `useterms`, `created_at`, `updated_at`) VALUES
(1, '<p><strong>Our Commitment to You:</strong></p>\r\n\r\n<p>Thank you for showing interest in our service. In order for us to provide you with our service, we are required to collect and process certain personal data about you and your activity.</p>\r\n\r\n<p>By entrusting us with your personal data, we would like to assure you of our commitment to keep such information private and to operate in accordance with all regulatory laws and all EU data protection laws, including General Data Protection Regulation (GDPR) 679/2016 (EU).</p>\r\n\r\n<p>We have taken measurable steps to protect the confidentiality, security and integrity of this data. We encourage you to review the following information carefully.</p>\r\n\r\n<p><strong>Grounds for data collection:</strong></p>\r\n\r\n<p>Processing of your personal information (meaning, any data which may potentially allow your identification with reasonable means; hereinafter &ldquo;Personal Data&rdquo;) is necessary for the performance of our contractual obligations towards you and providing you with our services, to protect our legitimate interests and for compliance with legal and financial regulatory obligations to which we are subject.</p>\r\n\r\n<p>When you use our services, you consent to the collection, storage, use, disclosure and other uses of your Personal Data as described in this Privacy Policy.</p>\r\n\r\n<p><strong>How do we receive data about you?</strong></p>\r\n\r\n<p>We receive your Personal Data from various sources:</p>\r\n\r\n<ol>\r\n	<li>When you voluntarily provide us with your personal details in order to create an account (for example, your name and email address)</li>\r\n	<li>When you use or access our site and services, in connection with your use of our services (for example, your financial transactions)</li>\r\n	<li>&nbsp;</li>\r\n</ol>\r\n\r\n<p><strong>What type of data we collect?</strong></p>\r\n\r\n<p>In order to open an account, and in order to provide you with our services we will need you to collect the following data:</p>\r\n\r\n<p><strong>Personal Data<br />\r\nWe collect the following Personal Data about you:</strong></p>\r\n\r\n<ul>\r\n	<li><em>Registration data</em>&nbsp;&ndash; your name, email address, phone number, occupation, country of residence, and your age (in order to verify you are over 18 years of age and eligible to participate in our service).</li>\r\n	<li><em>Voluntary data</em>&nbsp;&ndash; when you communicate with us (for example when you send us an email or use a &ldquo;contact us&rdquo; form on our site) we collect the personal data you provided us with.</li>\r\n	<li><em>Financial data</em>&nbsp;&ndash; by its nature, your use of our services includes financial transactions, thus requiring us to obtain your financial details, which includes, but not limited to your payment details (such as bank account details and financial transactions performed through our services).</li>\r\n	<li><em>Technical data</em>&nbsp;&ndash; we collect certain technical data that is automatically recorded when you use our services, such as your IP address, MAC address, device approximate location</li>\r\n	<li>Non Personal Data</li>\r\n</ul>\r\n\r\n<p>We record and collect data from or about your device (for example your computer or your mobile device) when you access our services and visit our site. This includes, but not limited to: your login credentials, UDID, Google advertising ID, IDFA, cookie identifiers, and may include other identifiers such your operating system version, browser type, language preferences, time zone, referring domains and the duration of your visits. This will facilitate our ability to improve our service and personalize your experience with us.<br />\r\nIf we combine Personal Data with non-Personal Data about you, the combined data will be treated as Personal Data for as long as it remains combined.</p>\r\n\r\n<p><strong>Tracking Technologies</strong></p>\r\n\r\n<p>When you visit or access our services we use (and authorize 3rd parties to use) pixels, cookies, events and other technologies (&ldquo;Tracking Technologies&ldquo;). Those allow us to automatically collect data about you, your device and your online behavior, in order to enhance your navigation in our services, improve our site&rsquo;s performance, perform analytics and customize your experience on it. In addition, we may merge data we have with data collected through said tracking technologies with data we may obtain from other sources and, as a result, such data may become Personal Data.<br />\r\nCookie Policy page.</p>\r\n\r\n<p><strong>How do we use the data We collect?</strong></p>\r\n\r\n<ul>\r\n	<li>Provision of service &ndash; we will use your Personal Data you provide us for the provision and improvement of our services to you.</li>\r\n	<li>Marketing purposes &ndash; we will use your Personal Data (such as your email address or phone number). For example, by subscribing to our newsletter you will receive tips and announcements straight to your email account. We may also send you promotional material concerning our services or our partners&rsquo; services (which we believe may interest you), including but not limited to, by building an automated profile based on your Personal Data, for marketing purposes. You may choose not to receive our promotional or marketing emails (all or any part thereof) by clicking on the &ldquo;unsubscribe&rdquo; link in the emails that you receive from us. Please note that even if you unsubscribe from our newsletter, we may continue to send you service-related updates and notifications or reply to your queries and feedback you provide us.</li>\r\n	<li>Opt-out of receiving marketing materials &ndash; If you do not want us to use or share your personal data for marketing purposes, you may opt-out in accordance with this &ldquo;Opt-out&rdquo; section. Please note that even if you opt-out, we may still use and share your personal information with third parties for non-marketing purposes (for example to fulfill your requests, communicate with you and respond to your inquiries, etc.). In such cases, the companies with whom we share your personal data are authorized to use your Personal Data only as necessary to provide these non-marketing services.</li>\r\n	<li>Analytics, surveys and research &ndash; we are always trying to improve our services and think of new and exciting features for our users. From time to time, we may conduct surveys or test features, and analyze the information we have to develop, evaluate and improve these features.</li>\r\n	<li>Protecting our interests &ndash; we use your Personal Data when we believe it&rsquo;s necessary in order to take precautions against liabilities, investigate and defend ourselves against any third-party claims or allegations, investigate and protect ourselves from fraud, protect the security or integrity of our services and protect the rights and property of the company, its users and/or partners.</li>\r\n	<li>Enforcing of policies &ndash; we use your Personal Data in order to enforce our policies, including but limited to our Terms &amp; Conditions.</li>\r\n	<li>Compliance with legal and regulatory requirements &ndash; we also use your Personal Data to investigate violations and prevent money laundering and perform due-diligence checks, and as required by law, regulation or other governmental authority, or to comply with a subpoena or similar legal process.</li>\r\n</ul>\r\n\r\n<p><strong>With whom do we share your Personal Data</strong></p>\r\n\r\n<ul>\r\n	<li>Internal concerned parties &ndash; we share your data with companies in our group, as well as our employees limited to those employees or partners who need to know the information in order to provide you with our services.</li>\r\n	<li>Financial providers and payment processors &ndash; we share your financial data about you for purposes of accepting deposits or performing risk analysis.</li>\r\n	<li>Business partners &ndash; we share your data with business partners, such as storage providers and analytics providers who help us provide you with our service.</li>\r\n	<li>Legal and regulatory entities &ndash; we may disclose any data in case we believe, in good faith, that such disclosure is necessary in order to enforce our Terms &amp; Conditions take precautions against liabilities, investigate and defend ourselves against any third party claims or allegations, protect the security or integrity of the site and our servers and protect the rights and property, our users and/or partners. We may also disclose your personal data where requested any other regulatory authority having control or jurisdiction over us, you or our associates or in the territories we have clients or providers, as a broker.</li>\r\n	<li>Merger and acquisitions &ndash; we may share your data if we enter into a business transaction such as a merger, acquisition, reorganization, bankruptcy, or sale of some or all of our assets. Any party that acquires our assets as part of such a transaction may continue to use your data in accordance with the terms of this Privacy Policy.</li>\r\n</ul>\r\n\r\n<p><strong>Transfer of data outside the EEA</strong></p>\r\n\r\n<p>Please note that some data recipients may be located outside the EEA. In such cases, we will transfer your data only to such countries as approved by the European Commission as providing an adequate level of data protection or enter into legal agreements ensuring an adequate level of data protection.</p>\r\n\r\n<p><strong>How we protect your data</strong></p>\r\n\r\n<p>We have implemented administrative, technical, and physical safeguards to help prevent unauthorized access, use, or disclosure of your personal data. Your data is stored on secure servers and isn&rsquo;t publicly available. We limit access of your data only to those employees or partners that need to know the information in order to enable the carrying out of the agreement between us.</p>\r\n\r\n<p>You need to help us prevent unauthorized access to your account by protecting your password appropriately and limiting access to your account (for example, by signing off after you have finished accessing your account). You will be solely responsible for keeping your password confidential and for all use of your password and your account, including any unauthorized use.</p>\r\n\r\n<p>While we seek to protect your data to ensure that it is kept confidential, we cannot absolutely guarantee its security. You should be aware that there is always some risk involved in transmitting data over the internet. While we strive to protect your Personal Data, we cannot ensure or warrant the security and privacy of your personal Data or other content you transmit using the service, and you do so at your own risk.</p>\r\n\r\n<p><strong>Retention</strong></p>\r\n\r\n<p>We will retain your personal data for as long as necessary to provide our services, and as necessary to comply with our legal obligations, resolve disputes, and enforce our policies. Retention periods will be determined taking into account the type of data that is collected and the purpose for which it is collected, bearing in mind the requirements applicable to the situation and the need to destroy outdated, unused data at the earliest reasonable time. Under applicable regulations, we will keep records containing client personal data, trading information, account opening documents, communications and anything else as required by applicable laws and regulations.</p>\r\n\r\n<p><strong>User Rights</strong></p>\r\n\r\n<ol>\r\n	<li>Receive confirmation as to whether or not personal data concerning you is being processed, and access your stored personal data, together with supplementary data.</li>\r\n	<li>Receive a copy of personal data you directly volunteer to us in a structured, commonly used and machine-readable format.</li>\r\n	<li>Request rectification of your personal data that is in our control.</li>\r\n	<li>Request erasure of your personal data.</li>\r\n	<li>Object to the processing of personal data by us.</li>\r\n	<li>Request to restrict processing of your personal data by us.</li>\r\n</ol>\r\n\r\n<p>However, please note that these rights are not absolute, and may be subject to our own legitimate interests and regulatory requirements.</p>\r\n\r\n<p><strong>How to Contact us?</strong></p>\r\n\r\n<p>If you wish to exercise any of the aforementioned rights, or receive more information, please contact our General Data Protection Officer (&ldquo;GDPO&rdquo;) using the details provided below:</p>\r\n\r\n<p>Email: support@onlintrade.com</p>\r\n\r\n<p>Attn. GDPO Compliance Officer</p>\r\n\r\n<p>If you decide to terminate your account, you may do so by emailing us at support@onlintrade.com. If you terminate your account, please be aware that personal information that you have provided us may still be maintained for legal and regulatory reasons (as described above), but it will no longer be accessible via your account.</p>\r\n\r\n<p><strong>Updates to this Policy</strong></p>\r\n\r\n<p>This Privacy Policy is subject to changes from time to time, at our sole discretion. The most current version will always be posted on our website (as reflected in the &ldquo;Last Updated&rdquo; heading). You are advised to check for updates regularly. In the event of material changes, we will provide you with a notice. By continuing to access or use our services after any revisions become effective, you agree to be bound by the updated Privacy Policy.</p>', 'yes', '2020-12-14 09:39:57', '2021-10-27 12:01:15');

-- --------------------------------------------------------

--
-- Table structure for table `testimonies`
--

CREATE TABLE `testimonies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ref_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `what_is_said` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonies`
--

INSERT INTO `testimonies` (`id`, `ref_key`, `position`, `name`, `what_is_said`, `picture`, `created_at`, `updated_at`) VALUES
(2, 'mZVhqO', 'Principal', 'Sarah Ona', 'I love this platform', '5EJXRd02.jpg1635329727', '2021-04-01 15:00:56', '2021-10-27 09:16:30'),
(3, 'EPVy3D', 'Investor', 'Mike Dinne', 'I have invested and its all good, please try it out guys', 'SIu0JZ01.jpg1635329714', '2021-10-27 09:16:14', '2021-10-27 09:17:31');

-- --------------------------------------------------------

--
-- Table structure for table `tp__transactions`
--

CREATE TABLE `tp__transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plan` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tp__transactions`
--

INSERT INTO `tp__transactions` (`id`, `plan`, `user`, `amount`, `type`, `created_at`, `updated_at`) VALUES
(12, 'From Account unused deposit to capital', 17, '10', 'Transfer', '2021-04-22 10:15:19', '2021-04-22 10:15:19'),
(13, 'From Profit to Unused Deposit', 17, '10', 'Transfer', '2021-04-22 10:18:35', '2021-04-22 10:18:35'),
(14, 'Bnous', 17, '20', 'Plan purchase', '2021-04-22 12:20:27', '2021-04-22 12:20:27'),
(15, 'Bnous', 17, '20', 'Plan purchase', '2021-04-22 12:27:12', '2021-04-22 12:27:12'),
(22, 'Premium', 17, '30', 'Plan purchase', '2021-06-07 11:38:47', '2021-06-07 11:38:47'),
(23, 'Credit', 45, '100', 'Deposit', '2021-06-08 08:06:21', '2021-06-08 08:06:21'),
(24, 'Premium', 45, '30', 'Plan purchase', '2021-06-08 08:07:25', '2021-06-08 08:07:25'),
(25, 'Credit', 17, '100', 'balance', '2021-10-05 12:14:43', '2021-10-05 12:14:43'),
(26, 'Credit', 46, '100', 'balance', '2021-10-05 12:32:06', '2021-10-05 12:32:06'),
(27, 'Professional', 46, '100', 'ROI', '2021-10-05 12:33:05', '2021-10-05 12:33:05'),
(28, 'Credit', 48, '100', 'balance', '2021-10-18 10:44:55', '2021-10-18 10:44:55'),
(29, 'Subscribed MT4 Trading', 17, '30', 'MT4 Trading', '2021-10-19 08:21:23', '2021-10-19 08:21:23'),
(30, 'Subscribed MT4 Trading', 17, '30', 'MT4 Trading', '2021-10-19 08:33:42', '2021-10-19 08:33:42'),
(31, 'Starter', 17, '20', 'Plan purchase', '2021-10-19 09:23:00', '2021-10-19 09:23:00'),
(32, 'SignUp Bonus', 49, '5', 'Bonus', '2021-10-25 07:01:59', '2021-10-25 07:01:59'),
(33, 'SignUp Bonus', 50, '5', 'Bonus', '2021-10-25 07:10:01', '2021-10-25 07:10:01'),
(34, 'Credit', 49, '100', 'balance', '2021-10-25 11:03:55', '2021-10-25 11:03:55'),
(35, 'Starter', 49, '20', 'Plan purchase', '2021-10-25 11:04:08', '2021-10-25 11:04:08'),
(36, 'SignUp Bonus', 51, '5', 'Bonus', '2021-10-25 12:12:13', '2021-10-25 12:12:13'),
(37, 'SignUp Bonus', 52, '5', 'Bonus', '2021-10-27 12:50:13', '2021-10-27 12:50:13'),
(38, 'SignUp Bonus', 53, '5', 'Bonus', '2021-10-31 12:24:40', '2021-10-31 12:24:40'),
(39, 'SignUp Bonus', 54, '5', 'Bonus', '2021-10-31 12:25:53', '2021-10-31 12:25:53'),
(40, 'Transfered to Sarah Ona', 17, '100', 'Fund Transfer', '2021-11-22 09:16:51', '2021-11-22 09:16:51'),
(41, 'Received from Tester Tests', 55, '100', 'Fund Transfer', '2021-11-22 09:16:51', '2021-11-22 09:16:51'),
(42, 'SignUp Bonus', 55, '5', 'Bonus', '2021-11-22 09:17:48', '2021-11-22 09:17:48'),
(43, 'Credit', 17, '100', 'balance', '2021-12-07 10:08:18', '2021-12-07 10:08:18'),
(44, 'Transfered to Test Accout', 17, '100', 'Fund Transfer', '2021-12-07 10:09:16', '2021-12-07 10:09:16'),
(45, 'Received from Tester Tests', 55, '100', 'Fund Transfer', '2021-12-07 10:09:16', '2021-12-07 10:09:16'),
(46, 'Transfered to Test Accout', 17, '50', 'Fund Transfer', '2022-01-07 09:47:54', '2022-01-07 09:47:54'),
(47, 'Received from Tester Tests', 55, '50', 'Fund Transfer', '2022-01-07 09:47:54', '2022-01-07 09:47:54'),
(48, 'Transfered to Test Accout', 17, '50', 'Fund Transfer', '2022-01-07 13:18:08', '2022-01-07 13:18:08'),
(49, 'Received from Tester Tests', 55, '50', 'Fund Transfer', '2022-01-07 13:18:08', '2022-01-07 13:18:08'),
(50, 'Transfered to Test Accout', 17, '200', 'Fund Transfer', '2022-01-14 11:52:04', '2022-01-14 11:52:04'),
(51, 'Received from Tester Tests', 55, '200', 'Fund Transfer', '2022-01-14 11:52:04', '2022-01-14 11:52:04'),
(52, 'Transfered to Test Accout', 17, '50', 'Fund Transfer', '2022-01-14 18:48:41', '2022-01-14 18:48:41'),
(53, 'Received from Tester Tests', 55, '50', 'Fund Transfer', '2022-01-14 18:48:41', '2022-01-14 18:48:41'),
(54, 'Transfered to Test Accout', 17, '10', 'Fund Transfer', '2022-01-14 18:52:00', '2022-01-14 18:52:00'),
(55, 'Received from Tester Tests', 55, '10', 'Fund Transfer', '2022-01-14 18:52:00', '2022-01-14 18:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `cstatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userupdate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assign_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_style` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'light',
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `swift_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acnt_type_active` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `btc_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eth_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ltc_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_plan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_bal` float DEFAULT NULL,
  `roi` float DEFAULT NULL,
  `bonus` float DEFAULT NULL,
  `ref_bonus` float DEFAULT NULL,
  `signup_bonus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_trade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_released` int(11) NOT NULL DEFAULT 0,
  `ref_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_card` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_verify` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entered_at` datetime DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `last_growth` datetime DEFAULT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `trade_mode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'on',
  `act_session` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `withdrawotp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sendotpemail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `sendroiemail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `sendpromoemail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `sendinvplanemail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `dob`, `cstatus`, `userupdate`, `assign_to`, `address`, `country`, `phone`, `dashboard_style`, `bank_name`, `account_name`, `account_number`, `swift_code`, `acnt_type_active`, `btc_address`, `eth_address`, `ltc_address`, `plan`, `user_plan`, `account_bal`, `roi`, `bonus`, `ref_bonus`, `signup_bonus`, `auto_trade`, `bonus_released`, `ref_by`, `ref_link`, `id_card`, `passport`, `account_verify`, `entered_at`, `activated_at`, `last_growth`, `status`, `trade_mode`, `act_session`, `remember_token`, `current_team_id`, `profile_photo_path`, `withdrawotp`, `sendotpemail`, `sendroiemail`, `sendpromoemail`, `sendinvplanemail`, `created_at`, `updated_at`) VALUES
(17, 'Tester Tests', 'test1234@happ.com', 'testmi1', '2021-06-08 07:33:49', '$2y$10$qKxg18xwqNYDnYLmrBfzrOP41/aBF26JC989SiBrt.NhSz80F5.Ma', NULL, NULL, '2021-09-23', NULL, 'This User is still on the group stage', '2', 'United State of Americas', 'USA', '04566444', 'light', 'Firstbank', 'Rolly Baker', '5021137787', '4664', NULL, 'hhsj878hjwjjhjkjksk', '333333333333', 'gttdddddds', '0', '9', 178, 50, 70, 0, '0', NULL, 0, NULL, 'http://127.0.0.1:8000/ref/testmi1', 'G1ttUX3.jpg1634646590', 'G1ttUXchikamso.jpg1634646590', 'Verified', '2021-10-19 10:23:00', NULL, NULL, 'active', 'on', NULL, NULL, NULL, NULL, NULL, 'No', 'Yes', 'No', 'Yes', '2021-03-12 11:59:19', '2022-01-14 18:52:00'),
(55, 'Test Accout', 'test123@happ.com', 'victorysyuus', '2021-11-22 09:16:17', '$2y$10$OwwstSMm0eBHVE/KuhU.Juuvt/JyTQLeKX1OwGZ6uAH71mDPBcN1C', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Australia', '+614566444', 'light', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 565, NULL, 5, NULL, 'received', NULL, 0, NULL, 'http://127.0.0.1:8000/ref/victorysyuus', NULL, NULL, NULL, NULL, NULL, NULL, 'active', 'off', NULL, 'udy5fIbSdxuoJxvL7fMOPt40cn0WXChSmOcUjtqGlD6sIvlGzgspa0il8VcX', NULL, NULL, NULL, 'Yes', 'Yes', 'Yes', 'Yes', '2021-11-22 09:16:05', '2022-01-14 18:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_plans`
--

CREATE TABLE `user_plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plan` int(11) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inv_duration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `last_growth` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wdmethods`
--

CREATE TABLE `wdmethods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minimum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maximum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charges_amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charges_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `swift_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wallet_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `network` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `methodtype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defaultpay` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wdmethods`
--

INSERT INTO `wdmethods` (`id`, `name`, `minimum`, `maximum`, `charges_amount`, `charges_type`, `duration`, `img_url`, `bankname`, `account_name`, `account_number`, `swift_code`, `wallet_address`, `barcode`, `network`, `methodtype`, `type`, `status`, `defaultpay`, `created_at`, `updated_at`) VALUES
(1, 'Bitcoin', '10', '10000', '0', 'percentage', 'Instant', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAN4AAADjCAMAAADdXVr2AAAAwFBMVEX+rwD////+/v7t7e3s7Oz+rgD6+vr39/f09PTx8fH+rAD7+/vs7e/s7/P+yWru6d3++e37tyn4w2P1zYH49vH4v1T8sgD8sw/+1Yv+/PX9xFv6uzjs6uL+7sz++Oru6Nj+0n/v4L72yXLx3bX+2ZT+5rbv5tDu4sX5vkb+9N3y2q/+78300Yv25cD+36X+yGD005j+5LHy1qL3yGz+3qD+wlH+vDX+zGjz1Zv6vEv48Nzz2Kj9uSP6uz/+4LT8z3aW1ss+AAAfEUlEQVR4nNVdCVsaPdeehbBkkiou4AgCgoKoVK2CrcX2//+rL8ss2ScD2Pf5cnlpTGbJPUnOlpOTICIp7MQktUOab5BcgxW2aWGHFoassEmyYassVOsTpZ4+tNGihU1aH7NCoT421bOW0MIo4S2RS0NeWr5faHQiN4o9ICjgNTR4DQUea15ZWFXPm08f1SzbZK8v4fGWJEVLhC8VCfDURidyo/4NvJCkBNNEc2GzzGKE/j/DQwhh3ExHy6s/P55PTy4vL9e/Pj8/f63Pz98nNy9/ZvPxkIxoivnr4LEP2WmQ1Ka5iObIiCepTXMdVs8KmzTXork4NNUnRT0vHI5nj9Onz24PwCIBCIr/QK8/WP+9uB0dky5FjYbSkqRsCS9tlaVejaalQYemVpOkFs21E5JL2nJhhxY2WWGb5podaz0pTJKkM55dnHR7DARNQRDQX/RvwP7QH5rYFdvzycvyLMFtuSU0l7DHd5qmUuX9QqN5++ilQVwSRdKZjYzoNSSi1igL6WAI+WAw1SPyiUcvk89eBoyjAhwLywQ8U/7DQQab15+LGKFEaUkcF0S5XZY25EbHSqP5CKaXZvCUaVOO9aZ9rKtEsRMjPFzd3AV5n4EcV/5HyGj/0Js20/sRH+ESfdKmVVg0Omop07acoPFB4RFKeHR90iXYAB99oPwt9h4A+eBk1UFWyv4h9/Yvb0dhCx0OnolqxMVUbtqnslyfXk02oOw2Swoq6mkvbr/djxHK6ENcUq0qUqfSH3pp0KapxVKZNRa2HIUfN4MCWpBPLd5vWe/lHRiURaC8Ich6mhUThNOF+Ca/9qmFNH8IxpDeXgZV3VYzQXj3/YhyixqMQe1ixhj2ZOvtMP3epfPt0AnC/ukco/+p1ILw/Gb7BdhYAjB4vQ5NVKM2vIYFnpHP5PAQGk/7XwUuA/j0QABa4DUs8BoKvIgy/LjNymKaTVghzbLCiBVyQkyzHVbYOjr9UnAZwG/LKKLvjDkjYk0pGt0xNpq3j5YGirioMgbrVMbDxy8HxxIEr3MvUmdkDLuxdYR+fNmc0wH2btLwX0ot+Hrwz8AFdIj2X8J/Bi8cvQbw34HjAO8eFFHND94Oc+/WOS5B8Sv/FwBJ48szIFCf4noqDB6HuP7cq0s58fi1AFc1PjkuAPrdu/Pp49vLy2q1mv3+8fw4eV9vtgGvrHxIAfDuKpQoZ2xodEuhnDX5XvO377hkWlz3283tw4dgYGmhIjtezH5OuWbo90QIL8Jd+J631BKm7462AKEhRHl7/XkdoyZXK4o2abaYcPkyGfTYWFUeYvpigw/8ZUJZGF5tq7uODEjQ/fZ9mXYw0umT0ZJ2dnQ/HQRCL1oxwt5zjL7GlJREb6ASHbmiO70+tiqNgqlJrMd4uLi568HqmQhfCYXx1xi89anmsWtgZu+G28nVWdNPH9Oz88dNUDkR4Wbe9Nf3vLX10abizWRQns9aFUNAtfGJ9UQBwcsJmYcBEMan/FLyHwxWOD6wUBauKigmhN1nooAqFlhtAhvrxQkURrdr6H4VgKfUwH1AqSV8c3YdGZXrF0ZK9oZHjVKrE/cYBfAkRnXgue2cKLxxyikQrK9SwQ6qNL+hwHPVZ8tM86kbIFwPkZedU7VSN0WDMy9sn7263gXB3aqZiDc1S9Oy0bTtqM/s0W08f3fOBrgZl6Zr2UqeFzIrtQdjSNciOgUogNtViGTBVSf8VYzBpFQuzp0fdbvAbm7mZ0oK0zv7ZyRs7i0Kv2Z9D+FZF+pyd4Gvv8AHkFpGn/aPSJjsKLSZmvaF14jx8NExBUHvGu8Lrz0aWPuOiICztt2Stj+8OMbLJzuXAMEM7yeUoSP7yIS90yF2rO/FRGbORWp57iGWJbXVlv4wfLHLuSBYVM09pWWK1EKoihXd4MHZMpQuH5bLxWJxPVelluU1KV4sHx7SyjXQuIGPnoQBqsgw/SXaXWoxosvWDeD0zGqLocMCLbbFguzdcTFBCTwymVkp+b1dGti6OoIRfrbyCNif492llifLYwnB/IHspib6eDzIxH8qJV6I8Caltg8vjd4b6voevrLKu7A7RrvCm1joMoCfc2xYvpR6ry9ot98EeNFl+c1A9wx5wGtEqVWwgAOiAFaYkowaQ9MmZwIwHVZTBRmeMPdkeJVzL6Ma33s2fJcxss+9ZrHqrohG0YtFtwTgR5RI8pS6lE/9D5I+KIxm8ATnkhOpP5fgJe71/2bePnzdtcwUOElU/4Ikf0AgW2UyrwDyN3ywyAuU24R2aTgrDMO89zg8ge/J8Aq5XfVPkJyu6GT+sHFg+B0X7xca5WLr4bGF3VBZyMdtJxQHpxuer1fS8Z15ttAPXk9qCdNLC7otocS+8ITBKcITuFgteNZGge4c1ZNaLizoKMn080qSe6+UWlR4Nvpk8koiBNTcrDui3qqmJPqAwGiFad6ahwFcjxQHArtpqF8yFXjSEurlwVnT3jSx4Ju0jHeZTUnjvhndr6HV8UMdArEIb1/GUHQM6tiG1aqGUGaWNOFgiJxeSdK0OSRbF6eVuf9Ab+QrtYQ3ZnRE/nE7XanwCtJySHiR2dwKnzxMSbQsXKqLWPx+SjMleDaWJcNTey/U4EnM0w2PjjiLFgN/YgO8ju4V8Gm6HfQIv8sXnJSlfL7g1JFX0aTeK+rJTTK8Yv3f7J/A5JFsbauTlaZG/g76c5Q3qpNfqjMG/Gi8GcxUpXBHxtDwZAyCjqpQDTQ2ymfwKaw2JaG5eWj/xvWcjR1Sy85sPSpMFEbKDqUFeIvUYhzZ8BTX9KX2EcrAjvAa4ZWpD0B/VAnvpxHd2sA9/rnMKcAzE3dCwiqEsuOt6bNs50g3yFTPvVJqOejcY5caBxm4ailzT6ac+FS+i7cErOjnUJfqVSeojlSvsXVOGdsq5UT5TdWUUyxFRyb1Ft6dleScUU6J76GxScmDpwpfq8X3VLYu8D2wC9/LSvHMNP3grUtqwaYuJ+K4Mi3+p0JZXqoOtOyBaWiFhxamO/pjZIUXNqmtNrN1ULstnzYkQ+ABofdCZrZFdCOA0HuQwGM37QCv0TRpf/BGgSdoDNhg+APwh2Wpnpl5R0c0HdN0JGWHfeGdT2lePzo+Fntv+0ELh6mvxiCRsqVhJoHusaQxCEpS88r0Oc4dWths0LWmQPC/6isVRWMCVrL5vJx8/zhrNn38C8psyyRfwZuWqO9Rq0/eMYbeBsEyNPhw0ZvaaO7yEJcfU1FB7daDi2XNPURx19B9ZC4xUxbX1gW2ubKNZYsvNb632cZFD6MqZ5H8WgrxboWRF1vnhfja1OJTbJJa4pZh5sFB6oD3+wDwpGshXBdrkj4b3PCJYbz1h6LUkrMstNBdSAI4E4SuXClsVMLbPcFgwk0Cmp1T9ArIC9HYwNzhMy7tnMUCPn43dN4lN/garNDkJr/eq0rKtQB+jlUrteYVUDbaQF0y0ze3UhdUY6l/CEJXHLs+WuHtl/jkwv4KN7Q1Bour+NnA0H0vWDMlmSybcBK6doAZ4YnzTZ97Jnldu5Zbnf12gDUN5I2IWbrUommIhKaN6sM7RALBPfaE12roq+MALJACz9RU0nnO/Xs79J4Ri34tM+z4wSOitd7wKc7h5UKPztKp8uvaceXovT1IS/7uIfKae4SSG7pve4Syucdbjub6Yh58xRZ1NVdnj/oW/1L73DOIGSZ4AXwPyw/r3uCmf2RArS6iKYkQWG3qBXQEO3eAocXTNjB5eu9HWji+F1zN1vlk0Q0M8C6Ud4DprkfwMo4r4BENqDNa3WxEz5q9KKdY3Kc+AT7wwje9+4ikLMBrz6VRRrMALnAlPOZzFqarX4qXdyFHau3WwdquhVNfeKluFoTfQ8GUZDCxwLW6eOOKOvCj78EjMgBeBIdSz7nv5lJ9VQV+ilEHzj613SDwWfGXzPwLTEJaJ0mWG/EV+zIG3oK/kSHqQKK7KrQXhqfO2aWM76GrQNPDgqNaUQfMFsSy3RX6oPFGypgyvhdGuquCsO6jm4jgIy7YOr7QCDx8dXgdGbflX7n6qacntgvfiY9MIL9t+fhFh3dXSi3xp7ZVCd7jukEV+Pw1UU74LUzTdEjTWZrm2eXqYuPcXAMHnvDQSJcog3FuSkLzvjpaQG9YM+pAuWItkWCupfLFZ+rhmO1zoFlGc0tfjtKoXSrwS9+oA0yZExEA+JtuxKK7UFq/oQwPkLFpXop3mnZMhkfeDd+alpuarRvHmIYvzbbxVZqrg2F0TmktYwzvUOu92x3C0SyLT6gOTmmNQVLlmuFVHwSBmcoSAuAZdUA3yYNumgll4VaFB/ppWLECpK8QJanBcMWbKa0QqTvAVlYqCjbYRyijW5U1owsZ2YhJLWwtXfRsJGNzHVYtcBnghfQdedSLIvwFcMOLIrbDpbgpyCOcsF9DT3j4GXKRobwbvmEO7xaqjIhI3B5RB5T6JPwGM9FElE8q4FGTJF3MLyIOlR+Z3Dh3wROWdGSNh9OzvxxeNJG3XFG6uYzEXf3i2hRfWkqSsj4p6gvaohB77vBILyzX/5PclYCUrmyjE87ohfzSjrzglgjvT+JOrNlcwOeQmZLigcr14GfVVDYxhg6ywpO8knTPdSITWuDd4kp1NiN1mqmI9BE1JaFhoEpJTJmvHyuJwbOwdWEBTN8Bhvn40Xk7V/p8ggmFt7rWsAoJW0fXWUwqoeLn7vCkbit7zwmvbTL/sxu/e8Nb6jffUHj4J9T0FKZJ7gFPTB69186XsnbvvSjcaDc/EXgN0ihlcMLN0e5zL+cxWYgr1uiqudce9cq1TvHLwJX33AsFVzP+biqyBlGy1uCdFFEHXKv6Wj2b3kWcroIxAE45uX8BvT8WnLT4EBhn8IRQdOwZcBHxS2NTvBbJVYFxvvLdlPn1xygI0y1QtD14WoybRgVbl/mexdeygu8RpVFdvSlu9OV71JVAf8Y1gccGhtx7v8tpUUtqubBRTqfUQto8s1FOX6mFKEXzvnIzgDMC7wEq8AD/ZjvCq9t7DN7U5gLuK3OS7FCTeInGHlCRLJCGJ9H1dgxgeVEqtKV85dYYeFCFQdnd2fRjP3DqqzGQpDqt0Ntx0HrTem+wW9SAtlXhs+t7LNu6B4E+MIMa+h5THbUhANfNgNsApal3uUuMwNDN90J71AEUD2zigLe2TpO2kgk3RChjWozYe3CyYwDLHYUyvsJqYntbT1sL95rSVvpAj0gt51CROeHboeAJvWeFF4v+FYo5660WvIVuTkqDxq9M2yvhvewYXdVXKJOiDkj8SjaI+No5s6gDc9UgAYJRMBwAtfdutdi4yvq9ZqXm9dioEDF4kSXqQHL2mEtuGjz4HmUvVWPjaq4M7FEfijWQQFoGx1vVbAyv0V6MQeq4nDFwwx+9HyHEb0IYD3/bN8UDcF0vgOVIY3zgOjjuafDm6NBSy+VwPB6PWBqP8+ziftJVzLiSaPjkuUKU0YI41RR2OCPDE6iUc7wPvLKtZuOe0DvcCK9o9kV1b14PXkMP/gDvOTz56cPdoorbey8Ql1CEKMcaLlGlfvNenc03HWruARyePDgBhWeeW95zz9IjxmS79hgVvN8zqrgJ3hgolBMEXgEs7eqsqfccyCzXgvWoEEz9YvViHd6fYKwKRKAX7s3WTbCAnrVdy/6F3YewVlxqwT0QCPDUwXkAeNbeU1YynNdCasnbDV7+hLz3xE97oN7LH5tbJHRC4vgnwzeqC0+R6v5Uzb3aGsNec0/Ft03RnnPPQDnPOkIoAsNSvXiqgVDfTC7U3quAV5nga1OIRVB6LRhdGXTH/4zvAXlSDM0xtjRvXLspycLLKlFrhdQ/JZfmDd64XnxPllrAgaUWlmEJgvwoAygGx3d9BdD7CPeSWojMqWoMe8mcGjz6qz+wpn4gyGYG8vLuCy9OtYUYInMyjSE4nMZgmnvwJB4Oh8wn4ow5RZTuEWfp8WrSdYSzClaeUgsyagxnA80YcdvycxVQC5uazAlyeNjhf9BsHt9knpMGlPDOuTdFKFT1PfK4OdXWA9lKTbT1A5mS8oe6TUm0cGkNqEU9h/1MSbq2DkYB3+v5NbaWQt+rWiEKadBdc+9Ra+UetpaY8frDWcrEbvOHF/HN9iZ41IPIC562q4JayqiBRFliuCzhmXdX1jIlBZXwGPMMdcep/O4ZUndfynw4g2e0c+Jn3UpdrOon+YJTkhRL9SSXKPUdXo81mbPoPXpptv6fJEWYbPGhiXnPdcD8VtmlhddC5nXQlAtDg5U6CjJPa8EQaFtj8FVnBdk59ymrWGPg9CnNgznIq3yAdEL9NQbm2TLF/4kVomzfuu32IN1jhej4f7++l8FbWrg7vNpjfS/dQmk4SKuz/7T3ji3EJQvUVQFvprqm0Z0KAd2/r/beyR5zT/QpA6VPmcfcC8vJF/DPnc1ieIGr5x56hsqtNMJJQAMNKPDAZogql+oNUQc0z4hcW5ejDminIuT+B/G5GoOXP4qPJs3roCkVSp4R/KsMIqNfC7D4tfjzPUXJ8eF7pJ7Jh6bBOVUvjXW+Z/FrKbySxIoDeSV5wsujDui0L7v9ZA+vpP+AT1kWCMcY5cIXnsWnLPMIlI1ln+qsr6kxKK+q0hiyFSPbPnEyOKs1BotHING3TP6c8lp/pddAqe9piVHOlvWmMptMbXzv1Kh6yvcb/DnPeNQBozeu+2tFDsYQFBQzf2bGGCInY0DmAEj09ptKxqDsP6Tvhn8xcxXXfKmDXX2pJzljyDSs3E/Mi63jV6geAppxMXhbydapYpB90Px37kudecJLHbuTJzzzpTZ+fg94+IfVZAiXu3vCh5wjqqzhNqxv50zP/WTOnHkVxksCDy9ssW/pt660c5r3MfCoA8kfHd5r4jhGt208ZrdpkxmV2Limh+KZ7V6qXjtcGfij8A99FwqLmEt3Ph9oDxG+hkLXiRJSFWPA6VsgruRI+h7Ra6oNk7qlJttDRGfAYXaA6etrAlsPy2BCPNhQFoGojTFi/hH2rShgjvbYARbz/Xtq39bdv2dwmykftn64unq4pmlFcldXLEtzD6vfP1/7zqNdwADtuX/PvvvSHXVArhejxwl/rHMquwZC92XwudIQ6Np9yc0c2uCAz023bUOde5nIYqKcJejSISLIjccVn4LGH6hY30PGvbOojDrAdD4Fnrbz2aXOosapbMg5WIIXYeUagy4MFjufudw+1+AFvvvWSS6MF+aQffujA9tj68Gs2WRx7luPOIfcLeoA25YfLV/OlQMTrIPTBMB4bdGKt7BqAaw66sCOMSOoqna7pmEjjA0/QILrNKqC54wZkalqHhE/TOt76Np41IyirTuT6yIeJa12xI+gjPjBRaMkMcZrSZxRB0g2+quJsio8mXJa4WmDk+sKpT9nokUdSHjhWvX3oPFaskvzAJaWaDuVSyj2o2AOkAjVZEKVyxvXGm2nURErKaiKlUTKjvUF3+KXH1t3DGQaqjiD52DrhoVPPVbSLpGuItOZFHXgmQZkmYd/w2p4lZGucqqxQ5yy0GCf0pq5YwLwIgqdASy94pSVuzhMUeae3FEHDMYjrTN2gwqDl2bxJnvUg6YhwjHonhV3lZGNTZIbjRHoYgxIj5qoDc6qBJS/LA8/lxWRjVmhNUZgPsb2ifBIsrY4A3slAPvfQ2Gzwz4RHoXb68bnbKAjHd1elJPxOth/K+L3Hig+J2dpluiqjqgDA3N4VSjpOoEcbEd+PoDlLfTIsP7JTATigocc0VULeIJXwANU7CT0Y1xGfO2qoyzV05vQ/NwVG7d8paUiCITyzefd35vFsIMF/4JOUrgKdHRXBWNsXKLH8vrclFSocvjc0H3OyMZh0x7ZWAi7bYlsDODmo7xpOGxgbD0kyxRAxUBX1MjGsTCt6seljqxxqYsjzjRTkhJ2O7/JK6p4/bjUItUwdd8eUcXzj/sfiSpujjVbxITfDR6wwwN7wPOMCS+bUcyfBK7sc88qtB3yHCJ97lkj+pe8n809RnnLBXzLeQyE2CpL9Y6oBLxePsGNdG3E67PjJkAGjw0BwSmgiC+QlE4JpqgDJk0MgCuhffQBEt+jefNpGucWqcV+1oDjiLPSYC4eUCcc3LznaRoNo9Ry2LNQIje8YnAWtuB/cxaKyeoSBAc9yWZveDVOstGoAg+doX2ZYIdziITeaxReSfscUFf/HCLdFaBpO0XKtP5vdwWQTtMQPRFkylnhn6Dqe7R9ZxtjA/sf8pVM38u0dTZuso4xHeMQsDPAGvnGbv41GVVgH55ThUZZL/A9YGMMoGQM1NSdDYG8JZn9uyzNO8Z+BljeqJwxeJ7gxtEe/gS33dj6uy74M7nW/1hdLXgGx1f3/L0qeP/s/L1clcv4mOv0xMgadSBnWbzedpKNIrXEsf101xJebud0n54YS/4FDJ5pA3+zfa96weT4joyxcQ1RCdpS7yXCTfLgtPsnlA8tog60OxPzdgc4SbRTDegDvvTkUiNj8D0ky3hyqcVzhlo2zeeta1ILY6b2c2e7Nc6dLW46EFt3HIZrO3fWDE8+NVgyTtQ4NVjYImWUOWseUFecGqyumNQ+NTiyRyqG4pnPu8HLdYla8OiZz2b7aX7mswmeZe6R5Dix23PuCYNzX6Esdp3YHRqVQjb3lJb9h89bt6FznrduZOvZVJ6Yxzpl8ISAep7gdgi2HqWvtg2a8DNGsdhoD6klv9Jgls8eGvxweC3Rx+MuLKIawguRrU/KUNTwqR17wMNXGyu6LvXa3w2eTXplLZueOeGhxRayBCC8OxbhjTYwT9ul6AlvgYfwc5CvL6ujiZ3164LX4BqDYe6xA+jsi8tw8OCceyh9uHp4WF1fXy+EucXqHzKfsoe0ij6RluCjJ3vAof4SFY02zj3zBv68EB/dWTZFEny9iyGWog7I6/tU5cKthCTB/yCrp4lUl+v/kn+CGF8gedna0QWLltJowd+UnSKlGHAKvpeZivDIeAJxNkAHs7ZDGi5EXGEE2+sVU1KYmR3sXcfYuTiuc7k7e76TrRcccmQIRlXShtdRMa3UCRybtCbXDjBtAuPho9FtJh8917ihTltfqaV0qtKDFUjveIvCr4GH8MyxX59Jh3ElPLvUUsx6B32hHbhdhSi2cWSV91fVCy1ZnDvAEZq5wHKjVf8CdnpixS4TljmzMlX2InC3areqd5l41RdOCR/vgeOjBnDzYY+K0Cqy0smlOmPINoiEN85zPWBweZVWDIHqPUQiY5hPneACuB4itdG1hbJy2oQ2+TN/HVy/dDCy7PAS1ArXBrdsAoXh6iTQ/MTEBOBJjLRt+fWFspIqhCv35yQAu89HGO0NL4xu1xUOlACeIqRHHfAwJanwSpZFZSnnS8lbwfmMDg7b7kobvKIeYbyc9Kq8Q2GwwnKjHfCybaj6rv5sqb4sHDoJDAcIt5OrlEcl6CSJHFWgeGhiqo8i3Jk/bko+Z3sX/FyGHZMrg9poWurDGIpZ/wYq3RvJFZvp9XFdxoDxcHFz16v6fkyQGCLH0ex+piTTtCGU6mpbjY8O0u7792XKSI2qNRnOQgnDs6P76cB40p3Wdb1not6ZPRR3k1pKeCSTvlcOUPaJyfzZvP68jjn1NsNDiMy1Zrh8mQx6sAJbpgjBwQc2KGCHgkdIzX0FBS1bRDF2v93cPnw0MU18cKIiO17MnqeflcjKBIla7Ih0tatQJnFcdHTiMUPyP8yPCvS7d+fTx7eXlz+r1ez3j+fHyft6Qx3oIdT3T9g/192DO4Clae4xZ8Bs1Z8Cp7mIewgyaZfm8qgDlEWRzK1dA1PhBQHfMAq1BIDhWkeCweMQ5+2LfRpNS33ZuqSKjU58R6gR9Q4Jkq5rodgRdWA/qUUe6/h6YOtAt8NjnQCWwnWwLy2bm2MlHQ5eA6EfrhHq0eQa18LeTRqqXkme8BoeGoNpKhNN2s6FPeeT10UQnMy9ot4ZNYbdVbPW0WnfYqc4XO/B4NtHs1mjUXI2NyU1JK+AiFtlGo0i1khD9i9gLAbh8dQAMDhY7xEJ7+lB6JgoKhiDodGJ0uikplCmTFB6rC6e37h3vu5BLgm41+vQNK2+TmrRNriF6feuKHfUHpyWrwBh/3SOWSjNfeApLC1fnTWoapaoA2GY3l6WW/h2ZgxAuJYa7r8fUZE8KttXFV3VaOc0nkWg7uq3r+rzswI645uBt+hY2Y9Ea5w+5KZvpX3mqAOSf0FeyKzUuzIGtT69mmwABDtTzhJb/9v9GKFqV/EDmpJMY105VjfER9cn3b02mpLP07+8HYUtFIsM3DMu9QGlFh0erUd4uLq5CwoVp0bvcRVxej/iXfJfgGeop478o5cJ1+KUrShmZIDvPqHa7yLGqI6jvxc89zCuEwpKqB/PTi83uUIHFEB5LttWA/rnk5dlGlJC6e0q7jv36qqz5eOqVh6H49nj9PKz2wOilgdK5a/XH6z/XtyOjok2j1w6qud5DEqj6pqSTGzdUc9sKa10tLz68+P59OTy8nL96/Pz89f6/Px9cvNyO5uPh/yb1Pel/ldSi6M+jnNLWFLaWgSzC6amZuf63v8DeAp5rbV8eUh4sQYvVprPhLKyUK1PlHpG9LTF51iBV9SX8GLlqKl8d6gqlCmNTuRGMXj/B407U9Wu6d3rAAAAAElFTkSuQmCC', NULL, NULL, NULL, NULL, 'ksjhhjhdjd', '938893993', 'Erc', 'crypto', 'both', 'enabled', 'yes', '2021-03-11 11:53:32', '2021-10-11 09:16:24'),
(2, 'Ethereum', '10', '2100', '0', 'percentage', 'Instant', 'https://lulo.com', NULL, NULL, NULL, NULL, 'dddddddddddddddddddddddd', '938893993', 'Erc', 'crypto', 'both', 'enabled', 'yes', '2021-03-22 10:36:03', '2021-10-14 09:27:15'),
(3, 'Litecoin', '100', '10000', '0', '0', 'Instant', 'https://lulo.com', NULL, NULL, NULL, NULL, 'hhhhhhhhhhhhhhhhhhhhhhh', 'hhhhhhhhhhh', 'Erc', 'crypto', 'both', 'enabled', 'yes', '2021-03-22 10:36:33', '2021-10-11 09:15:46'),
(7, 'Stripe', '10', '10000', '0', 'percentage', 'Automatic Payment', 'https://lulo.com', 'Automatic', 'Automatic', '4242424242424242', '344', NULL, NULL, NULL, 'currency', 'deposit', 'enabled', 'yes', '2021-10-06 13:51:37', '2021-10-11 09:15:19'),
(9, 'Paystack', '10', '10000', '0', 'percentage', 'Automatic Payment', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhcAAABeCAMAAACnz8b3AAAA1VBMVEX///8BGzMAw/cAGzMAGDEAvvZX0fkAACUAECwAGTIAABsAACHy/P8Awffg9/4wy/hXYGzy9PXR09WNl6Hk5ugAITunr7cAACQABykADit61/kAFC4AABdLWWl6f4cAABALLEWxucBx2/oAABHs7vDL8v0AACkAAAjl6OqutbzMz9PZ3N81RFWEjJVkcX5yfYm+xMlAUGEdLkKdo6oAAABhaHMsPE+HkJrq+f5NXW0SJTseNUpnc4AmM0V7hZGv6fyT4vun5vw3QVA+SViXm6GA2/rA7v2cnc5AAAAVtUlEQVR4nO1dCXvautKG2K28NLesXo5MAifchDUYKNAEwkmb9Pz/n/R5xZqRvNCPhPTC6/M8PQFrsZh5NTMayaXSGacAd0rLMZqV3rG7c8bHQIMoZWl3mZtj9+eMj4G5XmYgtxvH7tAZHwJ1IjF8ITfPcnGGjzoBfHGWizMCnPniY8CYtncYGcfuzZkvPggM06Y7KKR/7P78Hl98/8+h8NaP96dgTVn1tKfH7s9v8cWvrwfD53/f/An/CFCZVU+ldez+/AZffP96eXEwXH56fvtn/AOgyqx6fgi52Jcvng8oFj6+v8NTfniofz5ffD2sWFz+eIen/PD4H+CLw4rFxeXf7/CUHx7/A3xxlos3wJkvznIhwpkvznIhwpkvznIhwpkvznIhwpkvDi4XvaGHdyn0u/CaysuD+12+6Hp1d3+zW9Wson8OX1QTxB/1Btv1jePjzhqtBoXWdqo146H9LSwk3/d3wiGovloVfJjRLe6e3mB+39Su/bau726XD3NBF8OCkgr5opvbdMOdrK07/+lvyOh1IOp0apeH7naq+GVv7m7k+1fRwOXyBdfOceSiMakkmIc9W410QiORVikho3Etr5pqvaLqCo3VwNbXm7DMlql+EghL/77CQrz23bti71mAm9zxyNJtb4IIG1Oprd8uNx3hY6kqq57qDDS9cLl2+5ulblE1fnbTisZksGDKdbhiwRAYi7VOlJigZNskywm3gJvDF/UN072rYLwOHe8stHLWHZnKDvbNq/fJXDfBImS5TMn1dJBVS2NLTNv7BRJI1HKmHslPHDup35x597qOpTCw7+aiCpsE3KTtBKPaXzqEqmUETzacFTOBtaPHQjeqbK2KZULBqLptzaYSKGHrstf2QLHY3giW62tbzZNVWLZMLY3W4VSXyRfDtc4Ml02a/hP9+HRQsfhaaH2kpquM+NJlqdsi7CfxZUvbVPoszZemoIxkLQfdEWU/cjzpWhEJ3Ka8CCqu67Ay8zUeuYWl8E0FV5k8ruJ5fWCm3AQvMmYbHVQsKrhLJqvSq85+Yj/g/lbrTbMsbEI2YTZQJl9ULDA2qh5o4/Pl4VbOLr/+t4BUeHKhAfFdu00bq2L0lUlTKGM41ai4DL2rj8BXuhHIBVRhyrN56SesUSKRXMydlO4Fd8nk7jUUsg7hGEUEa8K0+Wqm1a3djy32b7mNuuuappxS1mNOZ8oQWRZf1DU4NPIsLPjP3wfLv3gumJlT04DKPc5EGhNeVBVmOw1mtpRWptx8BFrky0XHQrRC+Ilk8AjcCCmWnTFMp0BXwADTXiQXRfjCukraHIs4L6rYnoHvsFxsVZrZjP2UqFQGX+CnlvRJ6ViAfOGJaIZ2yU6dr2BO0IScBV8uShJqQ+GTqIxbWCd9Cj4eO/ksYFu+CBXli51c9F7MjPugV4P4olfRs0bNB9XjeTCDL6pNBT3K6P/76/4+IF/kXKrFOQ8dS84uA/4I5GJhw1vKGmdgbBGn2BX/076STQLhP8q6tD9fdCukyP2SiC9aBYrKu5FL54uxCcvQWaat/7bAfJEN9Rq5aO5jimkhRiAXAx3pso4nkmobKqCk+SPUyFXLENfDvfmiO81iCw6sXHSnpAhfymb0kKl8ATeiedAFdte7YS++8GyMGbCfq7M05wApcXQFctFYotnYvkedGqJOyU3faJhYhZoqX1f35gusqjkXKxeLgkQj0zCek8YXDRURr7ZlRuTLQVFILvZRFE/DWizpP5D8EkAFAjYdW8h6+Imi2WNUbfDzeVZZkSYk4m8F3o8vjNtCd+/AyIXvUBeDMuuGcgFqiuWiOoXOkGQxyvL8+bB4LiIXe2lKpPIRXDtfKwWFsUeiyogxWwpSa7/YK4p7yLbuXN84mmnLbFP2qFcqzhehwY8JLO9K5GIo5ZhXzEBY41Au2E93cjFGY0Jvd7ry5fNBA1sePn3OpYx9+aJMH3cd7trFJvwEkVA1UTmyAn0azuD3ctAk3Ani9WPTGforEvVNkzEO7FnAZ73bQl0LXeTJXsZFmeWLtZJ/d1KqW0rji46D7m0mqvLjwFJxUST3V8wXZWrpHojNhwska2cl4qCk/61sE13TTYvG+irgi9I98kgodMg6SH2VF/9TDURC1Ntk4IavjimHTe1s+PGdHgDFJKjO4q7iC1HjiY/ZqAoJBkAR0sFOLvo6F7opU28AHM0riuOfdF0tpfBFbwS7IOlMRODA6yMBvubLhUiyb1+2RqfTry9mvAERGoEeuj95X4TMNvWO25lfjYjIUYnkAnskkgMMjBVqNPBXBrCj5JUtUZ0/BjaLbO1cu2HHhwsboqMOizCaOOYdCkWpjPudjjGuNG2B/RDLRfeFowvZehkbg8bAGLfQCKhhl4V80YJPLJEK83BvIBYXF/lyweuDaffj32m4crhophb5qq6FSyo34zji25s3STmNL3p4QgeeanUKnZwyGQZyAUqYyLcdbu6ITW65iGx+/kV1hjlB1kZuZF1Xa1ONZ5NYLjoEcwK5NeIlmm5/ZoJKH6qhXPB8YaAfQRmxXt+R5AJLvErGrMvRq2B1igd3gZYTJKsFMnI2VhkjNlqxR2Kz+tFAjrwSuECIL+QmTn2pjRcTPh0gP1+rj0eAUhC968x4UmiHX43QNypchytNEj+HNqOZQcAXLkX2lAXG8UhygbVBh88WhAKhtsx68ZCDz8kUxS3nTgpfcB4JXTIKYkCzJVozc2FHPaOj0KEF+XyBw6+0jLyjAWd/xHKBnR5zhepe6dEdRI0rxXzhiffIBrWoDuTCI8kFFHlg8YSothAxKAFbu7CkpLS4cPYG0cKOL0o4FmEzv0UFNqeWA5uhd4M66pmQ05Wbl8iXyxfdJTIDFC7MOMTOTSQXfRM+Hj90pXnADirZ7NgN8oUktdtoWURC3tnH4At7xGdD1Cxg1UcLoCj8qBI+rbPhmdlCvuA8EmYsqj+hekZrZlVBWggl2uPLZmxkJJTm8oVbhkpPBGuYcxMxZjv4+AqyHm0KEkkmGpVtfZV8A/nCc+Aool2ljao5klxAbZFEazUrqPf2wu95C4o52QoKIk5J+AJ7JKEPF5Ypw6/iHIkHUXaEN6yeY+zoU6MmThvK5QsDmk9hkAGhip41lIsGzC0pW8L1DGPZbLFjWs8JEdM1lvIjyQUU1oroJpQYQEfdwEsFk6IsVNomDIDs5ILzSLTdfDBH5owTDfecjxUwRKArlZVIMnL54pVALhwLKinV4fpJKBfDJtB0OhKnRzeGoF/1nPUUPkfwSHIBpJUIMiw8vADNCIyl4RP4TKkI9RWtdCRBdOyRmHHDVWReBEIYjO8yc+lWVYj2wMtmHl9UoVelqkKl72qIVIKhuwUdsIol0WTzhUp52j2SXEC1FS/5b4AtodqectdmQBPFelZyoVWQyIUhzLDw0IVayKTOjPnwKrqsR06s8/gCBUvkmXjnxxp0KpKL7IhKCrL5omzxov0R4p3XaQ8D7rrxnW6gZ0x0HFavAmOBWXRDHon8FA0INkmUXcZHdaTkrV3KWguReS5fTIHpEBm5HCCrhHIxh8sqWrF0iRz7gq65Es+HXja7uPi05/pI2RTf1Yeq6gTBGPYTQSZXgCEMJjJywa2ZRsOK3ByZSfgYSKgMuvz/LORP7ckX9EU8AGNghYRysYKar+XusQmQY19IMMDv48tfBz5I6eLy733XU4n4rj4MQQZyAfRMypALBoxcuChxIZ6e0aILSMmvPYlWKwAkAsMo+/JFilxsBfngaBmnsFxkPwC7IBjhy4+vl58Oh4uvP/Izc9AkmTKPINW44fgiax4R80WjDe0IGrrtw1mKBxNguNQzUiXCf2BYaF++SJlHKiAkGc8jsKfiXWgYef5IahfeF4gvUuzOe2S0e3anKwPLIc3uhKzA/srYI3ECA8OwQLWqhezA+jI3y/OaNd1y+QKGJjLsTvautmDoUlw5jDy+EEfW3h2IL1IeDsYqgtgPimmk+KlbaC2wcoE9krBpFEO0H3C1jZWl+ZtAU/lCYjeF5McvNoAJuNSxEF0HNJT4qcyHdrFXiWC+sC28LC2IxL8/kNCL41quinaFez9WDxoCqsDB8mBB5QazAvJIgt+sC7OyJCIyWzqrylo3UzOlQMQwN975CryKlLgWMiWSuBb74Uwcjh/CXe2IL6TN1RV+Ekp+94SFwwHxhTiucwW3Tdr3YRwcqrs4Dp6yPuLjAa6RBJ4qygSXy+J5rToc1Keao1u2zNgv8f8Q5hly+aIP1TUtDi7giwbce5vCtavZLdigKlhP3aLlF8h4Ad4xEzwEXk9Vlvx8MIDeSLRuBk30smjdDBn7iC+Q7SHdGpxiprkHIYbGdrE2bS6XmxXRXL7Aaeai2R0nfUfrZmOUYKLxI9CteIYy1RbJqq8g/6KLhwnvqPn316Eywf96LigaXP6Fya+zT6G2RHNwBydE8OvsE49n0vkCeyS+p1qEhEDfhrV7U5chX7BZPpAvKL/lES/fitbZ8ZJnvM6OVmws3sK4D9mBJBlLonwt10F5X7LCstavTwcLYFxeXv7OfnZf7y20/N/FCVt0GX5hoSRNcyHIy0F6AMwF5JGozfrqEdapIw2srvRvD9zUMn9ClgoT81CRgcPPEhOk9RRPpYMnrM5JXg56vCmsvleJMjQke8cAwvxO7Jt5op2M5T+HEooQBc+/4PK1VJh11ON2bsbbwxYwzcibYBdgWDYWq8Q8X3AeiUpQjoW8huPcmBJVslUuVBLpYFyMlQsZhkN2bDgcL6IDPQY36PnoDEQiXH5PXZLHh74wF2ya0HCaeGOyMgF9BXxR6uKa2LzmA6+PfPqHlwIeonxwvdmPf4/G6pYLMepRYM/FCRGSrc1j27trNAWOOpQLLmsL14cylwwr6IvstFCS1hA+BDuPzFA2ljX3cwQGFYfYemhKcUaQ18DD7lit4YMgXsLm/ULYN5N4Wb0xvgXrOfoyY7/ZAG9OVRNj5bBiUfB8LeH+EZlMx4Y77BibJb9va3e+TfWFW65QyXIz7wyH/XHLjIz1DL7AHgl3UaC4YxLbETZ6IZVhgqZYqwRtzPAEYzrZTFXbJyY71Mk5l9detuVKvT8YuvPFo2hTLLtPAH2lWo+Lq3rfqG/WaOgiKU/Zb7ZBB/xIyUxyJLkQqqpi6bqj8wdGldkFToPfm+mfNqYHu2qEOz6RXAyyN3fSJ2Ya6b4kKiVRbekmE3Af8o7EnprFZ3lR246O51LNQCdxhmfwleLvDtJN8Y663b6ijnAELOJvyeKOBQlT2FP2p3ZfUCckPZbuI8lFtspyl7Lcla2uc3ezZ/MF9kjQxc4H1Xu4GkFJa+z649ztTBRITfIjs4K1ylqOiBqYOxn3iK5kH+Iyh/HYi0ZywX6W7Gd37/D9pHZUuRApRAYI4w4MMo/XEQDJBW+HA2jMNOKquCmFaDd3d3c3OvKLyuDYhBo+bAM+TGjCVjIO7RKB2bdc/PyP3b5lUFNy/sUWj4Uy6h1TLvbSFMkEYZ9JbgpVJl9wHgm4ZJkxL107uxmmKQcESdZZlETDZTJPvvcaBeacg7lWtJC9juxO8IyJXPSWeJtKZCcdSS720hQbHao4yk2IAMByUZplEA5YiBpk3Ym6CFrIpiQScksfuwPZYM9F2RQ6Lsfffx86GOnna3E+iXTTOaJc7KMpVEXJJ7XH7BSqHL7I8kjQOX0FDsAKdRkd+zg0s07CoKHzWLrKSjbnLlYuqotCR4XK8Qpgxnl82CeJcp6PJBf76EmTizV6grFHBZxcZHgkaH2yuixETZKD8+wF29UTxHIRzIiFAc9dqxQ4NIg9dw18zspFb4SNFfJwPLkorieKJkhJcqVMkxz+yclFr52af4UOxSgN1+kHbCZ8oXHLXt2XDNOExAsm1YWexSvwOygX1a2TfuhpeCkJ92Wd99vHodfg7IBDnw/+W/HO9NlYIiNhgkFtlF5Glh7B35xcZEz//ALeJvd8Hsod7eehN0tzN6JDl0KsrPTa/XNd2cdqwxb6/JZ30Iy1ZM91BTXBc6C5Db30qVH6deC030In/iK+sMZaiv1OnVbKNtDGg5Oi9LY+hzkKvFz0Uz0Sh2/OtfQszZQJv3TiY7AkwgKyDraIGZbwZHTvPmf8AHeZtPEoyjpNM1Ak5abCNLPK4At/sxYqrQ1KXz4fVDAK0QXmi5tSXxWeEENGGa+8778Iky71VgOF8Rw+zWaWdrY4PjUhwHxkCkKwoVbazU3K0fbdhej0HquJVo57G0Xw7JJCjdIWaDl/brzXsZQTAKk+BYawC07S2tk38bfYJ/F3pXz/++JgyeBfi4mFIB980HIITESSbZ3UM88T6K0sHZ7FVVZM3V+w3F5bCfQ2X3R+Z4WvVkB6ZnL7KMKWOk0neccH00XTeUhP1K/2qWbTxNgpU+/+BX//YOq/wwJUbDkj1082IcljEJGd1Xh1dItCe0qlltM24C/fberMiDg4bXDiWOBNE+Jtv28P0X6z2vjFMu0g31uiCtFniwyuiGEsHr1xCWhDkhXzthVtI55fJaiL9NmN3kADLRFVSk1+HY4rj+H7X0J9linRm5VswfV+2c2S6LYty4pt6dZ6IeyL/+xTW4/tGGrrs4kb9ZJBSnKhMRkRokSH38jUa+Zlyz9Ftc7UxKevDq4W7Jtpim1KOTzE+0d6tfl9+9aPMrdbW7egyA7dyUi582G16oM9UleDdzY1KJjcqSCfMCngvy+qeXMXvMfqujkauymnHMD+DYz7yrrdqkyMwTD9/l7NeFhr/mM4y/uizx6hMRg/LJuOV/Zbe7Tp1PLeviZEgRdmvT2K7U99B9Thbk/ubGgReu/4jr0TQ7H9Zu8AlERacBfwGW+Ej8IXaGlWFp1JdLL47/NfRfGr0Fvt8vFR+MKwQEhRkFp9unj+dFkcBc7+LoIPwhc4ydIq4AGdCv7dL251+XyIRo/FF1Xjqs7YjC7c6wlSrk4de6+PFHy1XSaOxBfVe8cyv01iP64mw3ipIKB4uthXLC6K7RzKxpH4wt9vKEnWz3lgXs650/nO00iCI8nFMfgiOr5ToqazflhaOlq9kPHRpieN0+EL/zCS3QKEQrnEB8Lt5z5lnA5fTLLTKdHL9U4dJ8MXA3E6xO4yP8JBQh8Hp8IXvWV2SihzVvgZpdPhCzd704l6jmlBnApfcC8WBhC8AOXEcSp8MTAztoBJuvDkt1PGycQ7++mZ15J+tjkx9swHv/x8iEZrcC/33SHqzIVhWeLNGlTDZzGdUfr+dR/BuDwIXZSGYJ+40j5Enfno3quCdwNI1mOhd9mdGr5/3uN48M+HsC481L9pu/cPO7TYGdcHwGDp+IeOJFwhK+Tm/pyVl4L/FMXhmuy6u/cPi/Oc3wi9+mJNdGL56fCWqTVb9XOU84wAw5pR394vFpvx3M3I0D5t/B9ASlqWmEpGkQAAAABJRU5ErkJggg==', 'Automatic', 'Automatic', '99388383', NULL, NULL, NULL, NULL, 'currency', 'deposit', 'enabled', 'yes', '2021-10-07 08:53:27', '2021-10-11 12:41:56'),
(10, 'Paypal', '10', '10000', '0', 'percentage', 'Instant Payment', 'https://lulo.com', 'Automatic', 'Automatic', '99388383', NULL, NULL, NULL, NULL, 'currency', 'deposit', 'enabled', 'yes', '2021-10-07 08:56:14', '2021-10-11 08:57:12'),
(12, 'Bank Transfer', '10', '10000', '0', 'percentage', 'Instant Payment', NULL, 'Mining Bank', 'Miller lauren', '99388383', '3222ASD', NULL, NULL, NULL, 'currency', 'both', 'enabled', 'yes', '2021-10-11 11:35:35', '2022-01-07 13:44:10'),
(13, 'Doge', '10', '10000', '2', 'percentage', 'Instant Payment', 'https://lulo.com', NULL, NULL, NULL, NULL, 'jjjjjjjjjjjjjjjjjjjjjjjyyuy', 'QRCODE’,’PDF417′,’DATAMATRIX', 'Erc', 'crypto', 'deposit', 'enabled', NULL, '2021-10-14 10:54:10', '2022-01-07 13:30:05');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `txn_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `columns` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_deduct` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_mode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paydetails` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `withdrawals`
--

INSERT INTO `withdrawals` (`id`, `txn_id`, `user`, `amount`, `columns`, `to_deduct`, `status`, `payment_mode`, `paydetails`, `created_at`, `updated_at`) VALUES
(19, NULL, 17, '100', NULL, '100', 'Processed', 'Bitcoin', NULL, '2021-10-18 09:28:09', '2021-10-18 09:28:54'),
(22, NULL, 17, '100', NULL, '100', 'Processed', 'Bank Transfer', NULL, '2021-10-19 15:11:53', '2021-10-19 15:12:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cp_transactions`
--
ALTER TABLE `cp_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crypto_accounts`
--
ALTER TABLE `crypto_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ipaddresses`
--
ALTER TABLE `ipaddresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mt4_details`
--
ALTER TABLE `mt4_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `paystacks`
--
ALTER TABLE `paystacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings_conts`
--
ALTER TABLE `settings_conts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `terms_privacies`
--
ALTER TABLE `terms_privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonies`
--
ALTER TABLE `testimonies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tp__transactions`
--
ALTER TABLE `tp__transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_plans`
--
ALTER TABLE `user_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wdmethods`
--
ALTER TABLE `wdmethods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `cp_transactions`
--
ALTER TABLE `cp_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `crypto_accounts`
--
ALTER TABLE `crypto_accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ipaddresses`
--
ALTER TABLE `ipaddresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `mt4_details`
--
ALTER TABLE `mt4_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `paystacks`
--
ALTER TABLE `paystacks`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings_conts`
--
ALTER TABLE `settings_conts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `terms_privacies`
--
ALTER TABLE `terms_privacies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testimonies`
--
ALTER TABLE `testimonies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tp__transactions`
--
ALTER TABLE `tp__transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `user_plans`
--
ALTER TABLE `user_plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wdmethods`
--
ALTER TABLE `wdmethods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
