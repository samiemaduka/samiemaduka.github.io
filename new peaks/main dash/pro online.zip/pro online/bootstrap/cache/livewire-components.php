<?php return array (
  'manage-deposit' => 'App\\Http\\Livewire\\ManageDeposit',
);