<?php $__env->startComponent('mail::message'); ?>
# Greetings!

<?php echo $demo->message; ?><br>

<?php if($demo->otpcode): ?>
  <h3><?php echo e($demo->otpcode); ?></h3>  
<?php endif; ?>

<br>
Kind regards,<br>
<?php echo e($demo->sender); ?>.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/bryngrgz/oct2021.brynamics.xyz/resources/views/emails/NewNotification.blade.php ENDPATH**/ ?>