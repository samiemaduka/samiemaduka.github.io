<div <?php echo e($attributes); ?>>
    <div class="mt-5">
        <div class="px-4 py-5 bg-<?php echo e($bg); ?> shadow text-<?php echo e($text); ?>">
            <?php echo e($content); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\resources\views/vendor/jetstream/components/action-section.blade.php ENDPATH**/ ?>