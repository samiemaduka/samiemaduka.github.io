<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'inline-flex items-center btn btn-secondary px-4 py-2 border'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/bryngrgz/oct2021.brynamics.xyz/resources/views/vendor/jetstream/components/secondary-button.blade.php ENDPATH**/ ?>