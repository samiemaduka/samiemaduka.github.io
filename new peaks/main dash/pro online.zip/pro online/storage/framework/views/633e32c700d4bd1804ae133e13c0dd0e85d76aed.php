<form method="POST" action="javascript:void(0)" id="updateprofileform">
    <?php echo csrf_field(); ?>
    <div class="form-row">
        <div class="form-group col-md-6">
            <h5 class="text-<?php echo e($text); ?>">Fullname</h5>
            <input type="text" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" value="<?php echo e(Auth::user()->name); ?>" name="name">
        </div>
        <div class="form-group col-md-6">
            <h5 class="text-<?php echo e($text); ?>">Email Address</h5>
            <input type="email" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" value="<?php echo e(Auth::user()->email); ?>" name="email" readonly>
        </div>
        <div class="form-group col-md-6">
            <h5 class="text-<?php echo e($text); ?>">Phone Number</h5>
            <input type="text" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" value="<?php echo e(Auth::user()->phone); ?>" name="phone">
        </div>
        <div class="form-group col-md-6">
            <h5 class="text-<?php echo e($text); ?>">Date of Birth</h5>
            <input type="date" value="<?php echo e(Auth::user()->dob); ?>" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>"  name="dob">
        </div>
        <div class="form-group col-md-6">
            <h5 class="text-<?php echo e($text); ?>">Nationality</h5>
            <textarea class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" placeholder="Full Address" name="address" row="3"><?php echo e(Auth::user()->address); ?></textarea>
        </div>
        
    </div>
    <button type="submit" class="btn btn-primary">Update Profile</button>
</form>

<script>
    
$('#updateprofileform').on('submit', function() {
    //alert('love');
    $.ajax({
        url: "<?php echo e(route('profile.update')); ?>",
        type: 'POST',
        data: $('#updateprofileform').serialize(),
        success: function(response) {
            if (response.status === 200) {
                $.notify({
                    // options
                    icon: 'flaticon-alarm-1',
	                title: 'Success',
                    message: response.success,
                },{
                    // settings
                    type: 'success',
                    allow_dismiss: true,
	                newest_on_top: false,
	                showProgressbar: true,
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    offset: 20,
                    spacing: 10,
                    z_index: 1031,
                    delay: 5000,
                    timer: 1000,
                    url_target: '_blank',
                    mouse_over: null,
                    animate: {
                        enter: 'animated fadeInDown',
                        exit: 'animated fadeOutUp'
                    },

                });
            } else {
               
            }
        },
        error: function(data) {
            console.log(data);
        },

    });
});
</script><?php /**PATH /home/bryngrgz/oct2021.brynamics.xyz/resources/views/profile/update-profile-information-form.blade.php ENDPATH**/ ?>