<div class="row">
    <div class="col-md-12">
        <form action="javascript:void(0)" method="POST" id="paypreform">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <h5 class="text-<?php echo e($text); ?>"> Deposit option:</h5>
                    <select name="deposit_option" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>">
                        <option value="<?php echo e($settings->deposit_option); ?>"> <?php echo e($settings->deposit_option); ?>(Current)</option>
                        <option value="manual">Manual</option>
                        <option  value="auto">Automatic</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    <h5 class="text-<?php echo e($text); ?>"> Withdrawal option:</h5>
                    <select name="withdrawal_option" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>">
                        <option value="<?php echo e($settings->withdrawal_option); ?>"><?php echo e($settings->withdrawal_option); ?>(Current)</option>
                        <option value="manual">Manual</option>
                        <option  value="auto">Automatic</option>
                    </select>
                </div> 
                <div class="form-group col-md-6">
                    <button type="submit" class="px-4 btn btn-primary">Save</button>
                </div> 
            </div>
            
        </form>
    </div>
</div><?php /**PATH /home/bryngrgz/oct2021.brynamics.xyz/resources/views/admin/Settings/PaymentSettings/withdrawal.blade.php ENDPATH**/ ?>